package com.ge.ScpTransport.ScpTransportPortalDemand.dto;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ItemNumberVO {
	
	private String itemNumber;
	
	private String itemDescription;

	public String getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	
	
	

}
