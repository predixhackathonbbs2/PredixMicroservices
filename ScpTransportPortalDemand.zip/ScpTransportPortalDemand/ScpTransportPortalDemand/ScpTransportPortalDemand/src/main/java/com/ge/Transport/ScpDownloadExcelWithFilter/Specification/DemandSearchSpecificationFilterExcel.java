package com.ge.Transport.ScpDownloadExcelWithFilter.Specification;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.ge.ScpTransport.ScpTransportPortalDemand.entity.GetsDemand;

public class DemandSearchSpecificationFilterExcel implements Specification<GetsDemand> {
	
	private GetsDemand filter;
	
	private String itemNumber;
	
	private String buyerName;
	
	private String supplierName;
	
	private String supplierCode;
	
	private String buissnessUnit;
	
	
	
	/*public DemandSearchSpecificationFilterExcel(GetsDemand filter){
		super();
		this.filter = filter;
		//this.filter1 = filter1;
	}*/
	
	
	public DemandSearchSpecificationFilterExcel(String itemNumber, String buyerName,
			String supplierName, String supplierCode, String buissnessUnit) {
		super();
		this.itemNumber = itemNumber;
		this.buyerName = buyerName;
		this.supplierName = supplierName;
		this.supplierCode = supplierCode;
		this.buissnessUnit = buissnessUnit;
		
		// TODO Auto-generated constructor stub
	}


	@Override
	public Predicate toPredicate(Root<GetsDemand> root, CriteriaQuery<?> query,
			CriteriaBuilder cb) {
			Predicate p = cb.disjunction();
			
			String itemNumber = this.getItemNumber();
			String buyerName = this.getBuyerName();
			String supplierName = this.getSupplierName();
			String supplierCode = this.getSupplierCode();
			String buisnessUnit = this.getBuissnessUnit();
		
			
			List<Predicate> predicates = new ArrayList<>();
			if (null != itemNumber && itemNumber.length()!=2) {
				predicates.add(cb.equal(root.get("itemNumber"),
						this.getItemNumber()));
			}
			if ((null != buyerName && buyerName.length()!=2)) {
				predicates.add(cb.and(cb.equal(root.get("buyerName"),
						this.getBuyerName())));
			}
			if (null != supplierName && supplierName.length()!=2) {
				predicates.add(cb.and(cb.equal(root.get("supplierName"),
						this.getSupplierName())));
			}
			if (null!=supplierCode && supplierCode.length()!=2 ) {
				predicates.add(cb.and(cb.equal(root.get("supplierCode"),
						this.getSupplierCode())));
			}
			if (null!=buisnessUnit && buisnessUnit.length()!=2)
					 {
				predicates.add(cb.and(cb.equal(root.get("buissnessUnit"),
						this.getBuissnessUnit())));
			}
				
		
		return andTogether(predicates, cb);
	}
	
	private Predicate andTogether(List<Predicate> predicates, CriteriaBuilder cb) {
	    return cb.and(predicates.toArray(new Predicate[0]));
	  }


	public GetsDemand getFilter() {
		return filter;
	}


	public void setFilter(GetsDemand filter) {
		this.filter = filter;
	}


	public String getItemNumber() {
		return itemNumber;
	}


	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}


	public String getBuyerName() {
		return buyerName;
	}


	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}


	public String getSupplierName() {
		return supplierName;
	}


	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}


	public String getSupplierCode() {
		return supplierCode;
	}


	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}


	public String getBuissnessUnit() {
		return buissnessUnit;
	}


	public void setBuissnessUnit(String buissnessUnit) {
		this.buissnessUnit = buissnessUnit;
	}
	

	

}

