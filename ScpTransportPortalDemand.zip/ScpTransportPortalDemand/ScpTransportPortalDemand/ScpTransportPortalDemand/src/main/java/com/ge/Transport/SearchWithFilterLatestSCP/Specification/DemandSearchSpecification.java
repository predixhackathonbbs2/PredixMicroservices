package com.ge.Transport.SearchWithFilterLatestSCP.Specification;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.ge.ScpTransport.ScpTransportPortalDemand.entity.GetsDemand;

public class DemandSearchSpecification implements Specification<GetsDemand> {
	
	private GetsDemand filter;
	
	//private ScpDemandId filter1;
	
	public DemandSearchSpecification(GetsDemand filter){
		super();
		this.filter = filter;
		//this.filter1 = filter1;
	}
	
	
	@Override
	public Predicate toPredicate(Root<GetsDemand> root, CriteriaQuery<?> query,
			CriteriaBuilder cb) {
			Predicate p = cb.disjunction();
		
		List<Predicate> predicates = new ArrayList<>();
		if (null != filter.getItemNumber() && "" != filter.getItemNumber()) {
			predicates.add(cb.equal(root.get("itemNumber"),
					filter.getItemNumber()));
		}
		if ((null != filter.getBuyerName() && "" != filter.getBuyerName())) {
			predicates.add(cb.and(cb.equal(root.get("buyerName"),
					filter.getBuyerName())));
		}
		if (null != filter.getSupplierName() && "" != filter.getSupplierName()) {
			predicates.add(cb.and(cb.equal(root.get("supplierName"),
					filter.getSupplierName())));
		}
		if (filter.getSupplierCode() != null && "" != filter.getSupplierCode()) {
			predicates.add(cb.and(cb.equal(root.get("supplierCode"),
					filter.getSupplierCode())));
		}
		if (filter.getBuissnessUnit() != null
				&& "" != filter.getBuissnessUnit()) {
			predicates.add(cb.and(cb.equal(root.get("buissnessUnit"),
					filter.getBuissnessUnit())));
		}
			
		 
		return andTogether(predicates, cb);
	}
	
	private Predicate andTogether(List<Predicate> predicates, CriteriaBuilder cb) {
	    return cb.and(predicates.toArray(new Predicate[0]));
	  }
	

	

}


