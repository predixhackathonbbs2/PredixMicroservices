package com.ge.Transport.SearchWithoutFilterLatest.entity;

import javax.persistence.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name="GETS_DEMAND")
@NamedQuery(name="GetsDemand.findAll", query="SELECT g FROM GetsDemand g")
public class GetsDemand implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="GETS_DEMAND_DISPOSITIONID_GENERATOR", sequenceName="SCP_DETAILS")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="GETS_DEMAND_DISPOSITIONID_GENERATOR")
	@Column(name="DISPOSITION_ID")
	private long dispositionId;

	@Column(name="APR_04_APR_10")
	private BigDecimal apr04Apr10;

	@Column(name="APR_11_APR_17")
	private BigDecimal apr11Apr17;

	@Column(name="APR_18_APR_24")
	private BigDecimal apr18Apr24;

	@Column(name="APR_25_MAY_01")
	private BigDecimal apr25May01;

	@Column(name="AUG_01_AUG_28")
	private BigDecimal aug01Aug28;

	@Column(name="AUG_29_OCT_02")
	private BigDecimal aug29Oct02;

	@Column(name="BUISSNESS_UNIT")
	private String buissnessUnit;

	@Column(name="BUYER_EMAIL")
	private String buyerEmail;

	@Column(name="BUYER_NAME")
	private String buyerName;

	@Column(name="FEB_29_MAR_06")
	private BigDecimal feb29Mar06;

	@Column(name="INVENTORY_ORGANIZATION")
	private String inventoryOrganization;

	@Column(name="ITEM_DESCRIPTION")
	private String itemDescription;

	@Column(name="ITEM_NUMBER")
	private String itemNumber;

	@Column(name="JAN_02_JAN_29")
	private BigDecimal jan02Jan29;

	@Column(name="JAN_30_FEB_26")
	private BigDecimal jan30Feb26;

	@Column(name="JUL_04_JUL_31")
	private BigDecimal jul04Jul31;

	@Column(name="MAR_07_MAR_13")
	private BigDecimal mar07Mar13;

	@Column(name="MAR_14_MAR_20")
	private BigDecimal mar14Mar20;

	@Column(name="MAR_21_MAR_27")
	private BigDecimal mar21Mar27;

	@Column(name="MAR_28_APR_03")
	private BigDecimal mar28Apr03;

	@Column(name="MAY_02_MAY_08")
	private BigDecimal may02May08;

	@Column(name="MAY_09_MAY_15")
	private BigDecimal may09May15;

	@Column(name="MAY_16_MAY_22")
	private BigDecimal may16May22;

	@Column(name="MAY_23_MAY_29")
	private BigDecimal may23May29;

	@Column(name="MAY_30_JUL_03")
	private BigDecimal may30Jul03;

	@Temporal(TemporalType.DATE)
	@Column(name="NEW_SCHEDULE_DATE")
	private Date newScheduleDate;

	@Column(name="NOV_28_JAN_01")
	private BigDecimal nov28Jan01;

	@Column(name="OCT_03_OCT_30")
	private BigDecimal oct03Oct30;

	@Column(name="OCT_31_NOV_27")
	private BigDecimal oct31Nov27;

	@Column(name="ORDER_QUANTITY")
	private BigDecimal orderQuantity;

	@Column(name="PRIMARY_UNIT_OF_MEASURE")
	private String primaryUnitOfMeasure;

	@Column(name="PRIMARY_UOM_CODE")
	private String primaryUomCode;

	@Column(name="PRODUCT_CODE")
	private String productCode;

	@Column(name="SUPPLIER_CODE")
	private String supplierCode;

	@Column(name="SUPPLIER_NAME")
	private String supplierName;

	//bi-directional many-to-one association to ScpDemandId
	/*@ManyToOne
	@JoinColumn(name="DEMAND_ID")
	private ScpDemandId scpDemandId;*/
	
	@Column(name="DEMAND_ID")
	private BigDecimal demandId;
	
	@Column(name="SENT_FLAG")
	private String sentFlag;
	
	@Column(name="PAST_DUE")
	private BigDecimal pastDue;
	
	@Column(name="USER_NAME")
	private String userName;
	
	
	@Column(name="ROLL_NAME")
	private String rollName;
	
	
	
	public String getSentFlag() {
		return sentFlag;
	}

	public void setSentFlag(String sentFlag) {
		this.sentFlag = sentFlag;
	}

	public String getEditFlag() {
		return editFlag;
	}

	public void setEditFlag(String editFlag) {
		this.editFlag = editFlag;
	}

	@Column(name="EDIT_FLAG")
	private String editFlag;
	

	public BigDecimal getDemandId() {
		return demandId;
	}

	public void setDemandId(BigDecimal demandId) {
		this.demandId = demandId;
	}

	public GetsDemand() {
	}

	public long getDispositionId() {
		return this.dispositionId;
	}

	public void setDispositionId(long dispositionId) {
		this.dispositionId = dispositionId;
	}

	public BigDecimal getApr04Apr10() {
		return this.apr04Apr10;
	}

	public void setApr04Apr10(BigDecimal apr04Apr10) {
		this.apr04Apr10 = apr04Apr10;
	}

	public BigDecimal getApr11Apr17() {
		return this.apr11Apr17;
	}

	public void setApr11Apr17(BigDecimal apr11Apr17) {
		this.apr11Apr17 = apr11Apr17;
	}

	public BigDecimal getApr18Apr24() {
		return this.apr18Apr24;
	}

	public void setApr18Apr24(BigDecimal apr18Apr24) {
		this.apr18Apr24 = apr18Apr24;
	}

	public BigDecimal getApr25May01() {
		return this.apr25May01;
	}

	public void setApr25May01(BigDecimal apr25May01) {
		this.apr25May01 = apr25May01;
	}

	public BigDecimal getAug01Aug28() {
		return this.aug01Aug28;
	}

	public void setAug01Aug28(BigDecimal aug01Aug28) {
		this.aug01Aug28 = aug01Aug28;
	}

	public BigDecimal getAug29Oct02() {
		return this.aug29Oct02;
	}

	public void setAug29Oct02(BigDecimal aug29Oct02) {
		this.aug29Oct02 = aug29Oct02;
	}

	public String getBuissnessUnit() {
		return this.buissnessUnit;
	}

	public void setBuissnessUnit(String buissnessUnit) {
		this.buissnessUnit = buissnessUnit;
	}

	public String getBuyerEmail() {
		return this.buyerEmail;
	}

	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}

	public String getBuyerName() {
		return this.buyerName;
	}

	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}

	public BigDecimal getFeb29Mar06() {
		return this.feb29Mar06;
	}

	public void setFeb29Mar06(BigDecimal feb29Mar06) {
		this.feb29Mar06 = feb29Mar06;
	}

	public String getInventoryOrganization() {
		return this.inventoryOrganization;
	}

	public void setInventoryOrganization(String inventoryOrganization) {
		this.inventoryOrganization = inventoryOrganization;
	}

	public String getItemDescription() {
		return this.itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public String getItemNumber() {
		return this.itemNumber;
	}

	public void setItemNumber(String itemNumber) {
		this.itemNumber = itemNumber;
	}

	public BigDecimal getJan02Jan29() {
		return this.jan02Jan29;
	}

	public void setJan02Jan29(BigDecimal jan02Jan29) {
		this.jan02Jan29 = jan02Jan29;
	}

	public BigDecimal getJan30Feb26() {
		return this.jan30Feb26;
	}

	public void setJan30Feb26(BigDecimal jan30Feb26) {
		this.jan30Feb26 = jan30Feb26;
	}

	public BigDecimal getJul04Jul31() {
		return this.jul04Jul31;
	}

	public void setJul04Jul31(BigDecimal jul04Jul31) {
		this.jul04Jul31 = jul04Jul31;
	}

	public BigDecimal getMar07Mar13() {
		return this.mar07Mar13;
	}

	public void setMar07Mar13(BigDecimal mar07Mar13) {
		this.mar07Mar13 = mar07Mar13;
	}

	public BigDecimal getMar14Mar20() {
		return this.mar14Mar20;
	}

	public void setMar14Mar20(BigDecimal mar14Mar20) {
		this.mar14Mar20 = mar14Mar20;
	}

	public BigDecimal getMar21Mar27() {
		return this.mar21Mar27;
	}

	public void setMar21Mar27(BigDecimal mar21Mar27) {
		this.mar21Mar27 = mar21Mar27;
	}

	
	public BigDecimal getMar28Apr03() {
		return mar28Apr03;
	}

	public void setMar28Apr03(BigDecimal mar28Apr03) {
		this.mar28Apr03 = mar28Apr03;
	}

	public BigDecimal getMay02May08() {
		return this.may02May08;
	}

	public void setMay02May08(BigDecimal may02May08) {
		this.may02May08 = may02May08;
	}

	public BigDecimal getMay09May15() {
		return this.may09May15;
	}

	public void setMay09May15(BigDecimal may09May15) {
		this.may09May15 = may09May15;
	}

	public BigDecimal getMay16May22() {
		return this.may16May22;
	}

	public void setMay16May22(BigDecimal may16May22) {
		this.may16May22 = may16May22;
	}

	public BigDecimal getMay23May29() {
		return this.may23May29;
	}

	public void setMay23May29(BigDecimal may23May29) {
		this.may23May29 = may23May29;
	}

	public BigDecimal getMay30Jul03() {
		return this.may30Jul03;
	}

	public void setMay30Jul03(BigDecimal may30Jul03) {
		this.may30Jul03 = may30Jul03;
	}

	public Date getNewScheduleDate() {
		return this.newScheduleDate;
	}

	public void setNewScheduleDate(Date newScheduleDate) {
		this.newScheduleDate = newScheduleDate;
	}

	public BigDecimal getNov28Jan01() {
		return this.nov28Jan01;
	}

	public void setNov28Jan01(BigDecimal nov28Jan01) {
		this.nov28Jan01 = nov28Jan01;
	}

	public BigDecimal getOct03Oct30() {
		return this.oct03Oct30;
	}

	public void setOct03Oct30(BigDecimal oct03Oct30) {
		this.oct03Oct30 = oct03Oct30;
	}

	public BigDecimal getOct31Nov27() {
		return this.oct31Nov27;
	}

	public void setOct31Nov27(BigDecimal oct31Nov27) {
		this.oct31Nov27 = oct31Nov27;
	}

	public BigDecimal getOrderQuantity() {
		return this.orderQuantity;
	}

	public void setOrderQuantity(BigDecimal orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public String getPrimaryUnitOfMeasure() {
		return this.primaryUnitOfMeasure;
	}

	public void setPrimaryUnitOfMeasure(String primaryUnitOfMeasure) {
		this.primaryUnitOfMeasure = primaryUnitOfMeasure;
	}

	public String getPrimaryUomCode() {
		return this.primaryUomCode;
	}

	public void setPrimaryUomCode(String primaryUomCode) {
		this.primaryUomCode = primaryUomCode;
	}

	public String getProductCode() {
		return this.productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getSupplierCode() {
		return this.supplierCode;
	}

	public void setSupplierCode(String supplierCode) {
		this.supplierCode = supplierCode;
	}

	public String getSupplierName() {
		return this.supplierName;
	}

	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public BigDecimal getPastDue() {
		return pastDue;
	}

	public void setPastDue(BigDecimal pastDue) {
		this.pastDue = pastDue;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getRollName() {
		return rollName;
	}

	public void setRollName(String rollName) {
		this.rollName = rollName;
	}

	/*public ScpDemandId getScpDemandId() {
		return this.scpDemandId;
	}

	public void setScpDemandId(ScpDemandId scpDemandId) {
		this.scpDemandId = scpDemandId;
	}*/
}