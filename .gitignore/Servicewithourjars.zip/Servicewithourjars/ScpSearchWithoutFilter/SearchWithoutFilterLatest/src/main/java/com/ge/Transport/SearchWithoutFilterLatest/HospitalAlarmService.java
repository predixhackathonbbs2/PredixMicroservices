package com.ge.Transport.SearchWithoutFilterLatest;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.Transport.SearchWithoutFilterLatest.dto.AlarmEvent;
import com.ge.Transport.SearchWithoutFilterLatest.dto.BackLogCalcVO;
import com.ge.Transport.SearchWithoutFilterLatest.dto.CumBackLogCalcVO;
import com.ge.Transport.SearchWithoutFilterLatest.dto.DemandsDetailsVO;
import com.ge.Transport.SearchWithoutFilterLatest.dto.PlannedSupplierCalcVO;
import com.ge.Transport.SearchWithoutFilterLatest.dto.SupplierCommitCalcLatestVO;
import com.ge.Transport.SearchWithoutFilterLatest.dto.SupplierCommitCalcVO;
import com.ge.Transport.SearchWithoutFilterLatest.entity.AlarmEventEntity;
import com.ge.Transport.SearchWithoutFilterLatest.entity.GetsDemand;
import com.ge.Transport.SearchWithoutFilterLatest.repository.IAlarmEventEntityRepository;
import com.ge.Transport.SearchWithoutFilterLatest.repository.IDemandSearchEntityRepository;

@RestController
public class HospitalAlarmService {

	@Autowired
	private IAlarmEventEntityRepository alarmService;
	
	@Autowired
	private IDemandSearchEntityRepository demandRepo;

	@RequestMapping("/SearchWithoutFilterLatest")
	public @ResponseBody List<AlarmEvent> helloWorld() {
		List<AlarmEvent> events = new ArrayList<AlarmEvent>();
		List<AlarmEventEntity> entities = this.alarmService.findAll();
		for (AlarmEventEntity entity:entities) {
			events.add(entity.toAlarmEvent());
		}
		return events;
	}
	@RequestMapping("/getDemandAllDetailsWithOutFilter")
	public @ResponseBody List<DemandsDetailsVO> getDemandAllDetailsWithOutFilter() {
		 List<DemandsDetailsVO> demandVos = new ArrayList<DemandsDetailsVO>();
		 DemandsDetailsVO demandVo = null;
		 BackLogCalcVO backLogCalcVO = new BackLogCalcVO();
		 CumBackLogCalcVO cumBackLogCalcVO =null;
		 SupplierCommitCalcVO supplierCommitCalcVO = new SupplierCommitCalcVO(); //equv cum backlog vo
		 PlannedSupplierCalcVO plannedSupplierCalcVO = new PlannedSupplierCalcVO();//equv baclogvo
		// SupplierCommitCalcLatestVO calcLatestVO = new SupplierCommitCalcLatestVO();
		 System.out
			.println("Testing the service");
		 //BigDecimal testValue = null;
		// QuantityTypeVO quantityTypeVO = null;
		// DemandDateVO dateVO = null;
		// List<QuantityTypeVO> quantityVoList = new ArrayList<QuantityTypeVO>();
		 //List<DemandDateVO>  demandDateVoList = new ArrayList<DemandDateVO>();
		 try {
				List<GetsDemand> demandList = demandRepo.findAll(new Sort(Sort.Direction.ASC, "dispositionId"));
				
				for(GetsDemand demands : demandList){
					demandVo = new DemandsDetailsVO();
					//backLogCalcVO = new BackLogCalcVO();
					cumBackLogCalcVO = new CumBackLogCalcVO();
					//quantityTypeVO = new QuantityTypeVO();
					//dateVO = new DemandDateVO();
					
					if(demands.getSentFlag().equalsIgnoreCase("false")){
						demandVo.setItemNumber("");
						demandVo.setItemDescription("");
						demandVo.setSupplierName("");
						demandVo.setInventoryOrganization("");
					}else{
						
						demandVo.setItemNumber(demands.getItemNumber());
						demandVo.setItemDescription(demands.getItemDescription());
						demandVo.setSupplierName(demands.getSupplierName());
						demandVo.setInventoryOrganization(demands.getInventoryOrganization());
					}
					
					
					demandVo.setDispositionId(demands.getDispositionId());
					//demandVo.setItemNumber(demands.getItemNumber());
					//demandVo.setItemDescription(demands.getItemDescription());
					//demandVo.setSupplierName(demands.getSupplierName());
					//demandVo.setInventoryOrganization(demands.getInventoryOrganization());
					//setting quantity type
				//	quantityTypeVO.setQuantityType(demands.getProductCode());
					
					//setting the date type
					demandVo.setQuantityType(demands.getProductCode());
					
					if(demands.getProductCode().equalsIgnoreCase("Planned for Supplier")){
						
						plannedSupplierCalcVO.setBackpastDue(demands.getPastDue());
						
						if(null!= demands.getApr04Apr10()){
							plannedSupplierCalcVO.setBackapr04Apr10(demands.getApr04Apr10());
						}else{
							plannedSupplierCalcVO.setBackapr04Apr10(new BigDecimal(0));
						}
						if(null!= demands.getApr11Apr17()){
							plannedSupplierCalcVO.setBackapr11Apr17(demands.getApr11Apr17());
						}else{
							plannedSupplierCalcVO.setBackapr11Apr17(new BigDecimal(0));
						}
						
						if(null!= demands.getApr18Apr24()){
							plannedSupplierCalcVO.setBackapr18Apr24(demands.getApr18Apr24());
						}else{
							plannedSupplierCalcVO.setBackapr18Apr24(new BigDecimal(0));
						}
						
						if(null!= demands.getApr25May01()){
							plannedSupplierCalcVO.setBackapr25May01(demands.getApr25May01());
						}else{
							plannedSupplierCalcVO.setBackapr25May01(new BigDecimal(0));
						}
						if(null!= demands.getAug01Aug28()){
							plannedSupplierCalcVO.setBackaug01Aug28(demands.getAug01Aug28());	
						}else{
							plannedSupplierCalcVO.setBackaug01Aug28(new BigDecimal(0));
						}
						
						if(null!= demands.getAug29Oct02()){
							plannedSupplierCalcVO.setBackaug29Oct02(demands.getAug29Oct02());
						}else{
							plannedSupplierCalcVO.setBackaug29Oct02(new BigDecimal(0));
						}
						
						if(null!= demands.getFeb29Mar06()){
							plannedSupplierCalcVO.setBackfeb29Mar06(demands.getFeb29Mar06());
							
						}else{
							plannedSupplierCalcVO.setBackfeb29Mar06(new BigDecimal(0));
						}
								
						if(null!= demands.getJan02Jan29()){
							plannedSupplierCalcVO.setBackjan02Jan29(demands.getJan02Jan29());
						}else{
							plannedSupplierCalcVO.setBackjan02Jan29(new BigDecimal(0));
						}
						if(null!= demands.getJan30Feb26()){
							plannedSupplierCalcVO.setBackjan30Feb26(demands.getJan30Feb26());
						}else{
							plannedSupplierCalcVO.setBackjan30Feb26(new BigDecimal(0));
						}
						if(null!= demands.getJul04Jul31()){
							plannedSupplierCalcVO.setBackjul04Jul31(demands.getJul04Jul31());
						}else{
							plannedSupplierCalcVO.setBackjul04Jul31(new BigDecimal(0));
						}
						if(null != demands.getMar07Mar13()){
							plannedSupplierCalcVO.setBackmar07Mar13(demands.getMar07Mar13());	
						}else{
							plannedSupplierCalcVO.setBackmar07Mar13(new BigDecimal(0));
						}
						if(null!= demands.getMar14Mar20()){
							plannedSupplierCalcVO.setBackmar14Mar20(demands.getMar14Mar20());
						}else{
							plannedSupplierCalcVO.setBackmar14Mar20(new BigDecimal(0));
						}
						if(null!= demands.getMar21Mar27()){
							plannedSupplierCalcVO.setBackmar21Mar27(demands.getMar21Mar27());
						}else{
							plannedSupplierCalcVO.setBackmar21Mar27(new BigDecimal(0));
						}
						if(null!= demands.getMar28Apr03()){
							plannedSupplierCalcVO.setBackmar28Apr03((demands.getMar28Apr03()));
						}else{
							plannedSupplierCalcVO.setBackmar28Apr03((new BigDecimal(0)));
						}
						if(null!= demands.getMay02May08()){
							plannedSupplierCalcVO.setBackmay02May08(demands.getMay02May08());
						}else{
							plannedSupplierCalcVO.setBackmay02May08(new BigDecimal(0));
						}
						if(null!= demands.getMay09May15()){
							plannedSupplierCalcVO.setBackmay09May15(demands.getMay09May15());
						}else{
							plannedSupplierCalcVO.setBackmay09May15(new BigDecimal(0));
						}
						if(null!= demands.getMay16May22()){
							plannedSupplierCalcVO.setBackmay16May22(demands.getMay16May22());
						}else{
							plannedSupplierCalcVO.setBackmay16May22(new BigDecimal(0));
						}
						if(null!= demands.getMay23May29()){
							plannedSupplierCalcVO.setBackmay23May29(demands.getMay23May29());
						}else{
							plannedSupplierCalcVO.setBackmay23May29(new BigDecimal(0));
						}
						if(null!= demands.getMay30Jul03()){
							plannedSupplierCalcVO.setBackmay30Jul03(demands.getMay30Jul03());
						}else{
							plannedSupplierCalcVO.setBackmay30Jul03(new BigDecimal(0));
						}
						if(null!= demands.getNov28Jan01()){
							plannedSupplierCalcVO.setBacknov28Jan01(demands.getNov28Jan01());
						}else{
							plannedSupplierCalcVO.setBacknov28Jan01(new BigDecimal(0));
						}
						if(null!= demands.getOct03Oct30()){
							plannedSupplierCalcVO.setBackoct03Oct30(demands.getOct03Oct30());
						}else{
							plannedSupplierCalcVO.setBackoct03Oct30(new BigDecimal(0));
						}
						if(null!= demands.getOct31Nov27()){
							plannedSupplierCalcVO.setBackoct31Nov27(demands.getOct31Nov27());
						}else{
							plannedSupplierCalcVO.setBackoct31Nov27(new BigDecimal(0));
						}
						
						
						
						//setting it to main VO
						demandVo.setApr04Apr10(plannedSupplierCalcVO.getBackapr04Apr10());
						demandVo.setApr11Apr17(plannedSupplierCalcVO.getBackapr11Apr17());
						demandVo.setApr18Apr24(plannedSupplierCalcVO.getBackapr18Apr24());
						demandVo.setApr25May01(plannedSupplierCalcVO.getBackapr25May01());
						demandVo.setAug01Aug28(plannedSupplierCalcVO.getBackaug01Aug28());
						demandVo.setAug29Oct02(plannedSupplierCalcVO.getBackaug29Oct02());
						demandVo.setFeb29Mar06(plannedSupplierCalcVO.getBackfeb29Mar06());
						demandVo.setJan02Jan29(plannedSupplierCalcVO.getBackjan02Jan29());
						demandVo.setJan30Feb26(plannedSupplierCalcVO.getBackjan30Feb26());
						demandVo.setJul04Jul31(plannedSupplierCalcVO.getBackjul04Jul31());
						demandVo.setMar07Mar13(plannedSupplierCalcVO.getBackmar07Mar13());
						demandVo.setMar14Mar20(plannedSupplierCalcVO.getBackmar14Mar20());
						demandVo.setMar21Mar27(plannedSupplierCalcVO.getBackmar21Mar27());
						demandVo.setMar28Apr03((plannedSupplierCalcVO.getBackmar28Apr03()));
						demandVo.setMay02May08(plannedSupplierCalcVO.getBackmay02May08());
						demandVo.setMay09May15(plannedSupplierCalcVO.getBackmay09May15());
						demandVo.setMay16May22(plannedSupplierCalcVO.getBackmay16May22());
						demandVo.setMay23May29(plannedSupplierCalcVO.getBackmay23May29());
						demandVo.setMay30Jul03(plannedSupplierCalcVO.getBackmay30Jul03());
						demandVo.setNov28Jan01(plannedSupplierCalcVO.getBacknov28Jan01());
						demandVo.setOct03Oct30(plannedSupplierCalcVO.getBackoct03Oct30());
						demandVo.setOct31Nov27(plannedSupplierCalcVO.getBackoct31Nov27());
						demandVo.setPastDue(plannedSupplierCalcVO.getBackpastDue());
					}
					if(demands.getProductCode().equalsIgnoreCase("Supplier Commit to Planned")){
						System.out
								.println("Inside the loopp");
						
						if(null!= demands.getApr04Apr10()){
							supplierCommitCalcVO.setcumbackapr04Apr10(demands.getApr04Apr10());
						}else{
							supplierCommitCalcVO.setcumbackapr04Apr10(new BigDecimal(0));
						}
						if(null!= demands.getApr11Apr17()){
							supplierCommitCalcVO.setcumbackapr11Apr17(demands.getApr11Apr17());
						}else{
							supplierCommitCalcVO.setcumbackapr11Apr17(new BigDecimal(0));
						}
						if(null!= demands.getApr18Apr24()){
							supplierCommitCalcVO.setcumbackapr18Apr24(demands.getApr18Apr24());
						}else{
							supplierCommitCalcVO.setcumbackapr18Apr24(new BigDecimal(0));
						}
						if(null!= demands.getApr25May01()){
							supplierCommitCalcVO.setcumbackapr25May01(demands.getApr25May01());
						}else{
							supplierCommitCalcVO.setcumbackapr25May01(new BigDecimal(0));
						}
						if(null!= demands.getAug01Aug28()){
							supplierCommitCalcVO.setcumbackaug01Aug28(demands.getAug01Aug28());
						}else{
							supplierCommitCalcVO.setcumbackaug01Aug28(new BigDecimal(0));
						}
						if(null!= demands.getAug29Oct02()){
							supplierCommitCalcVO.setcumbackaug29Oct02(demands.getAug29Oct02());
						}else{
							supplierCommitCalcVO.setcumbackaug29Oct02(new BigDecimal(0));
						}
						if(null!= demands.getFeb29Mar06()){
							supplierCommitCalcVO.setcumbackfeb29Mar06(demands.getFeb29Mar06());
						}else{
							supplierCommitCalcVO.setcumbackfeb29Mar06(new BigDecimal(0));
						}
						if(null!= demands.getJan02Jan29()){
							supplierCommitCalcVO.setcumbackjan02Jan29(demands.getJan02Jan29());
						}else{
							supplierCommitCalcVO.setcumbackjan02Jan29(new BigDecimal(0));
						}
						if(null!= demands.getJan30Feb26()){
							supplierCommitCalcVO.setcumbackjan30Feb26(demands.getJan30Feb26());
						}else{
							supplierCommitCalcVO.setcumbackjan30Feb26(new BigDecimal(0));
						}
						if(null!= demands.getJul04Jul31()){
							supplierCommitCalcVO.setcumbackjul04Jul31(demands.getJul04Jul31());
						}else{
							supplierCommitCalcVO.setcumbackjul04Jul31(new BigDecimal(0));
						}
						if(null!= demands.getMar07Mar13()){
							supplierCommitCalcVO.setcumbackmar07Mar13(demands.getMar07Mar13());
						}else{
							supplierCommitCalcVO.setcumbackmar07Mar13(new BigDecimal(0));
						}
						if(null!= demands.getMar14Mar20()){
							supplierCommitCalcVO.setcumbackmar14Mar20(demands.getMar14Mar20());
						}else{
							supplierCommitCalcVO.setcumbackmar14Mar20(new BigDecimal(0));
						}
						if(null!= demands.getMar21Mar27()){
							supplierCommitCalcVO.setcumbackmar21Mar27(demands.getMar21Mar27());
						}else{
							supplierCommitCalcVO.setcumbackmar21Mar27(new BigDecimal(0));
						}
						if(null!= demands.getMar28Apr03()){
							supplierCommitCalcVO.setcumbackmar28Apr03(demands.getMar28Apr03());
						}else{
							supplierCommitCalcVO.setcumbackmar28Apr03(new BigDecimal(0));
						}
						if(null!= demands.getMay02May08()){
							supplierCommitCalcVO.setcumbackmay02May08(demands.getMay02May08());
						}else{
							supplierCommitCalcVO.setcumbackmay02May08(new BigDecimal(0));
						}
						if(null!= demands.getMay09May15()){
							supplierCommitCalcVO.setcumbackmay09May15(demands.getMay09May15());
						}else{
							supplierCommitCalcVO.setcumbackmay09May15(new BigDecimal(0));
						}
						if(null!= demands.getMay16May22()){
							supplierCommitCalcVO.setcumbackmay16May22(demands.getMay16May22());
						}else{
							supplierCommitCalcVO.setcumbackmay16May22(new BigDecimal(0));
						}
						if(null != demands.getMay23May29()){
							supplierCommitCalcVO.setcumbackmay23May29(demands.getMay23May29());
						}else{
							supplierCommitCalcVO.setcumbackmay23May29(new BigDecimal(0));
						}
						
						if(null != demands.getMay30Jul03()){
							supplierCommitCalcVO.setcumbackmay30Jul03(demands.getMay30Jul03());
						}else{
							supplierCommitCalcVO.setcumbackmay30Jul03(new BigDecimal(0));
						}
						
						if(null != demands.getNov28Jan01()){
							supplierCommitCalcVO.setcumbacknov28Jan01(demands.getNov28Jan01());
						}else{
							supplierCommitCalcVO.setcumbacknov28Jan01(new BigDecimal(0));
						}
						
						if(null != demands.getOct03Oct30()){
							supplierCommitCalcVO.setcumbackoct03Oct30(demands.getOct03Oct30());
						}else{
							supplierCommitCalcVO.setcumbackoct03Oct30(new BigDecimal(0));
						}
						
						if(null != demands.getOct31Nov27()){
							supplierCommitCalcVO.setcumbackoct31Nov27(demands.getOct31Nov27());
						}else{
							supplierCommitCalcVO.setcumbackoct31Nov27(new BigDecimal(0));
						}
						
						
						supplierCommitCalcVO.setcumbackpastDue(demands.getPastDue());
						
						//setting it to main VO
						
						demandVo.setApr04Apr10(supplierCommitCalcVO.getcumbackapr04Apr10());
						demandVo.setApr11Apr17(supplierCommitCalcVO.getcumbackapr11Apr17());
						demandVo.setApr18Apr24(supplierCommitCalcVO.getcumbackapr18Apr24());
						demandVo.setApr25May01(supplierCommitCalcVO.getcumbackapr25May01());
						demandVo.setAug01Aug28(supplierCommitCalcVO.getcumbackaug01Aug28());
						demandVo.setAug29Oct02(supplierCommitCalcVO.getcumbackaug29Oct02());
						demandVo.setFeb29Mar06(supplierCommitCalcVO.getcumbackfeb29Mar06());
						demandVo.setJan02Jan29(supplierCommitCalcVO.getcumbackjan02Jan29());
						demandVo.setJan30Feb26(supplierCommitCalcVO.getcumbackjan30Feb26());
						demandVo.setJul04Jul31(supplierCommitCalcVO.getcumbackjul04Jul31());
						demandVo.setMar07Mar13(supplierCommitCalcVO.getcumbackmar07Mar13());
						demandVo.setMar14Mar20(supplierCommitCalcVO.getcumbackmar14Mar20());
						demandVo.setMar21Mar27(supplierCommitCalcVO.getcumbackmar21Mar27());
						demandVo.setMar28Apr03((supplierCommitCalcVO.getcumbackmar28Apr03()));
						demandVo.setMay02May08(supplierCommitCalcVO.getcumbackmay02May08());
						demandVo.setMay09May15(supplierCommitCalcVO.getcumbackmay09May15());
						demandVo.setMay16May22(supplierCommitCalcVO.getcumbackmay16May22());
						demandVo.setMay23May29(supplierCommitCalcVO.getcumbackmay23May29());
						demandVo.setMay30Jul03(supplierCommitCalcVO.getcumbackmay30Jul03());
						demandVo.setNov28Jan01(supplierCommitCalcVO.getcumbacknov28Jan01());
						demandVo.setOct03Oct30(supplierCommitCalcVO.getcumbackoct03Oct30());
						demandVo.setOct31Nov27(supplierCommitCalcVO.getcumbackoct31Nov27());
						demandVo.setPastDue(supplierCommitCalcVO.getcumbackpastDue());
						
						
						System.out
								.println("Testing : " + supplierCommitCalcVO.getcumbackapr04Apr10());
					}
					else if(demands.getProductCode().equalsIgnoreCase("Backlog")){
						backLogCalcVO.setBackpastDue(demands.getPastDue());
						
						//Planned for Supplier - Supplier Commit to Planned
						
					
						backLogCalcVO.setBackapr04Apr10(plannedSupplierCalcVO.getBackapr04Apr10().subtract(supplierCommitCalcVO.getcumbackapr04Apr10()));
						
						backLogCalcVO.setBackapr11Apr17(plannedSupplierCalcVO.getBackapr11Apr17().subtract(supplierCommitCalcVO.getcumbackapr11Apr17()));
						backLogCalcVO.setBackapr18Apr24(plannedSupplierCalcVO.getBackapr18Apr24().subtract(supplierCommitCalcVO.getcumbackapr18Apr24()));
						backLogCalcVO.setBackapr25May01(plannedSupplierCalcVO.getBackapr25May01().subtract(supplierCommitCalcVO.getcumbackapr25May01()));
						backLogCalcVO.setBackaug01Aug28(plannedSupplierCalcVO.getBackaug01Aug28().subtract(supplierCommitCalcVO.getcumbackaug01Aug28()));
						backLogCalcVO.setBackaug29Oct02(plannedSupplierCalcVO.getBackaug29Oct02().subtract(supplierCommitCalcVO.getcumbackaug29Oct02()));
						backLogCalcVO.setBackfeb29Mar06(plannedSupplierCalcVO.getBackfeb29Mar06().subtract(supplierCommitCalcVO.getcumbackfeb29Mar06()));
						backLogCalcVO.setBackjan02Jan29(plannedSupplierCalcVO.getBackjan02Jan29().subtract(supplierCommitCalcVO.getcumbackjan02Jan29()));
						backLogCalcVO.setBackjan30Feb26(plannedSupplierCalcVO.getBackjan30Feb26().subtract(supplierCommitCalcVO.getcumbackjan30Feb26()));
						backLogCalcVO.setBackjul04Jul31(plannedSupplierCalcVO.getBackjul04Jul31().subtract(supplierCommitCalcVO.getcumbackjul04Jul31()));
						backLogCalcVO.setBackmar07Mar13(plannedSupplierCalcVO.getBackmar07Mar13().subtract(supplierCommitCalcVO.getcumbackmar07Mar13()));
						backLogCalcVO.setBackmar14Mar20(plannedSupplierCalcVO.getBackmar14Mar20().subtract(supplierCommitCalcVO.getcumbackmar14Mar20()));
						backLogCalcVO.setBackmar21Mar27(plannedSupplierCalcVO.getBackmar21Mar27().subtract(supplierCommitCalcVO.getcumbackmar21Mar27()));
						backLogCalcVO.setBackmar28Apr03((plannedSupplierCalcVO.getBackmar28Apr03().subtract(supplierCommitCalcVO.getcumbackmar28Apr03())));
						backLogCalcVO.setBackmay02May08(plannedSupplierCalcVO.getBackmay02May08().subtract(supplierCommitCalcVO.getcumbackmay02May08()));
						backLogCalcVO.setBackmay09May15(plannedSupplierCalcVO.getBackmay09May15().subtract(supplierCommitCalcVO.getcumbackmay09May15()));
						backLogCalcVO.setBackmay16May22(plannedSupplierCalcVO.getBackmay16May22().subtract(supplierCommitCalcVO.getcumbackmay16May22()));
						backLogCalcVO.setBackmay23May29(plannedSupplierCalcVO.getBackmay23May29().subtract(supplierCommitCalcVO.getcumbackmay23May29()));
						backLogCalcVO.setBackmay30Jul03(plannedSupplierCalcVO.getBackmay30Jul03().subtract(supplierCommitCalcVO.getcumbackmay30Jul03()));
						backLogCalcVO.setBacknov28Jan01(plannedSupplierCalcVO.getBacknov28Jan01().subtract(supplierCommitCalcVO.getcumbacknov28Jan01()));
						backLogCalcVO.setBackoct03Oct30(plannedSupplierCalcVO.getBackoct03Oct30().subtract(supplierCommitCalcVO.getcumbackoct03Oct30()));
						backLogCalcVO.setBackoct31Nov27(plannedSupplierCalcVO.getBackoct31Nov27().subtract(supplierCommitCalcVO.getcumbackoct31Nov27()));
						
						//setting the details to MAIN vo
						
						demandVo.setApr04Apr10(backLogCalcVO.getBackapr04Apr10());
						demandVo.setApr11Apr17(backLogCalcVO.getBackapr11Apr17());
						demandVo.setApr18Apr24(backLogCalcVO.getBackapr18Apr24());
						demandVo.setApr25May01(backLogCalcVO.getBackapr25May01());
						demandVo.setAug01Aug28(backLogCalcVO.getBackaug01Aug28());
						demandVo.setAug29Oct02(backLogCalcVO.getBackaug29Oct02());
						demandVo.setFeb29Mar06(backLogCalcVO.getBackfeb29Mar06());
						demandVo.setJan02Jan29(backLogCalcVO.getBackjan02Jan29());
						demandVo.setJan30Feb26(backLogCalcVO.getBackjan30Feb26());
						demandVo.setJul04Jul31(backLogCalcVO.getBackjul04Jul31());
						demandVo.setMar07Mar13(backLogCalcVO.getBackmar07Mar13());
						demandVo.setMar14Mar20(backLogCalcVO.getBackmar14Mar20());
						demandVo.setMar21Mar27(backLogCalcVO.getBackmar21Mar27());
						demandVo.setMar28Apr03((backLogCalcVO.getBackmar28Apr03()));
						demandVo.setMay02May08(backLogCalcVO.getBackmay02May08());
						demandVo.setMay09May15(backLogCalcVO.getBackmay09May15());
						demandVo.setMay16May22(backLogCalcVO.getBackmay16May22());
						demandVo.setMay23May29(backLogCalcVO.getBackmay23May29());
						demandVo.setMay30Jul03(backLogCalcVO.getBackmay30Jul03());
						demandVo.setNov28Jan01(backLogCalcVO.getBacknov28Jan01());
						demandVo.setOct03Oct30(backLogCalcVO.getBackoct03Oct30());
						demandVo.setOct31Nov27(backLogCalcVO.getBackoct31Nov27());
						demandVo.setPastDue(backLogCalcVO.getBackpastDue());
						
					}else if(demands.getProductCode().equalsIgnoreCase("Cum.Backlog")){
						//demandVo.setPastDue(demands.getPastDue());
						
						if(null!= demands.getApr11Apr17()){
							cumBackLogCalcVO.setcumbackapr11Apr17(demands.getApr11Apr17());
						}else{
							cumBackLogCalcVO.setcumbackapr11Apr17(new BigDecimal(0));
						}
						
						if(null!= demands.getApr18Apr24()){
							cumBackLogCalcVO.setcumbackapr18Apr24(demands.getApr18Apr24());
						}else{
							cumBackLogCalcVO.setcumbackapr18Apr24(new BigDecimal(0));
						}
						
						if(null!= demands.getApr25May01()){
							cumBackLogCalcVO.setcumbackapr25May01(demands.getApr25May01());
						}else{
							cumBackLogCalcVO.setcumbackapr25May01(new BigDecimal(0));
						}
						
						if(null!= demands.getAug01Aug28()){
							cumBackLogCalcVO.setcumbackaug01Aug28(demands.getAug01Aug28());
						}else{
							cumBackLogCalcVO.setcumbackaug01Aug28(new BigDecimal(0));
						}
						
						if(null!= demands.getAug29Oct02()){
							cumBackLogCalcVO.setcumbackaug29Oct02(demands.getAug29Oct02());
						}else{
							cumBackLogCalcVO.setcumbackaug29Oct02(new BigDecimal(0));
						}
						
						if(null!= demands.getFeb29Mar06()){
							cumBackLogCalcVO.setcumbackfeb29Mar06(demands.getFeb29Mar06());
						}else{
							cumBackLogCalcVO.setcumbackfeb29Mar06(new BigDecimal(0));
						}
						
						if(null!= demands.getJan02Jan29()){
							cumBackLogCalcVO.setcumbackjan02Jan29(demands.getJan02Jan29());
						}else{
							cumBackLogCalcVO.setcumbackjan02Jan29(new BigDecimal(0));
						}
						
						if(null!= demands.getJan30Feb26()){
							cumBackLogCalcVO.setcumbackjan30Feb26(demands.getJan30Feb26());
						}else{
							cumBackLogCalcVO.setcumbackjan30Feb26(new BigDecimal(0));
						}
						
						
						if(null!= demands.getJul04Jul31()){
							cumBackLogCalcVO.setcumbackjul04Jul31(demands.getJul04Jul31());
						}else{
							cumBackLogCalcVO.setcumbackjul04Jul31(new BigDecimal(0));
						}
						
						if(null!= demands.getMar07Mar13()){
							cumBackLogCalcVO.setcumbackmar07Mar13(demands.getMar07Mar13());
						}else{
							cumBackLogCalcVO.setcumbackmar07Mar13(new BigDecimal(0));
						}
						
						
						if(null!= demands.getMar14Mar20()){
							cumBackLogCalcVO.setcumbackmar14Mar20(demands.getMar14Mar20());
						}else{
							cumBackLogCalcVO.setcumbackmar14Mar20(new BigDecimal(0));
						}
						
						if(null!= demands.getMar21Mar27()){
							cumBackLogCalcVO.setcumbackmar21Mar27(demands.getMar21Mar27());
						}else{
							cumBackLogCalcVO.setcumbackmar21Mar27(new BigDecimal(0));
						}
						
						if(null!= demands.getMar28Apr03()){
							cumBackLogCalcVO.setcumbackmar28Apr03(demands.getMar28Apr03());
						}else{
							cumBackLogCalcVO.setcumbackmar28Apr03(new BigDecimal(0));
						}
						
						if(null!= demands.getMay02May08()){
							cumBackLogCalcVO.setcumbackmay02May08(demands.getMay02May08());
						}else{
							cumBackLogCalcVO.setcumbackmay02May08(new BigDecimal(0));
						}
						
						if(null!= demands.getMay09May15()){
							cumBackLogCalcVO.setcumbackmay09May15(demands.getMay09May15());
						}else{
							cumBackLogCalcVO.setcumbackmay09May15(new BigDecimal(0));
						}
						
						if(null!= demands.getMay16May22()){
							cumBackLogCalcVO.setcumbackmay16May22(demands.getMay16May22());
						}else{
							cumBackLogCalcVO.setcumbackmay16May22(new BigDecimal(0));
						}
						if(null!= demands.getMay23May29()){
							cumBackLogCalcVO.setcumbackmay23May29(demands.getMay23May29());
						}else{
							cumBackLogCalcVO.setcumbackmay23May29(new BigDecimal(0));
						}
						
						if(null!= demands.getMay30Jul03()){
							cumBackLogCalcVO.setcumbackmay30Jul03(demands.getMay30Jul03());
						}else{
							cumBackLogCalcVO.setcumbackmay30Jul03(new BigDecimal(0));
						}
						if(null!= demands.getNov28Jan01()){
							cumBackLogCalcVO.setcumbacknov28Jan01(demands.getMay30Jul03());
						}else{
							cumBackLogCalcVO.setcumbacknov28Jan01(new BigDecimal(0));
						}
						
						if(null!= demands.getOct03Oct30()){
							cumBackLogCalcVO.setcumbackoct03Oct30(demands.getOct03Oct30());
						}else{
							cumBackLogCalcVO.setcumbackoct03Oct30(new BigDecimal(0));
						}
						
						if(null!= demands.getOct31Nov27()){
							cumBackLogCalcVO.setcumbackoct31Nov27(demands.getOct31Nov27());
						}else{
							cumBackLogCalcVO.setcumbackoct31Nov27(new BigDecimal(0));
						}
						
						if(null!= demands.getApr04Apr10()){
							cumBackLogCalcVO.setcumbackapr04Apr10(demands.getApr04Apr10());
						}else{
							cumBackLogCalcVO.setcumbackapr04Apr10(new BigDecimal(0));
						}
						
						
						if(null!= demands.getPastDue()){
							cumBackLogCalcVO.setcumbackpastDue(demands.getPastDue());
						}else{
							cumBackLogCalcVO.setcumbackpastDue(new BigDecimal(0));
						}
						
						
						
						
						//cumBackLogCalcVO.setcumbackpastDue((backLogCalcVO.getBackpastDue()));
						
						cumBackLogCalcVO.setcumbackfeb29Mar06(cumBackLogCalcVO.getcumbackpastDue().add(backLogCalcVO.getBackfeb29Mar06()));
						
						cumBackLogCalcVO.setcumbackmar07Mar13(cumBackLogCalcVO.getcumbackfeb29Mar06().add(backLogCalcVO.getBackmar07Mar13()));
						
						cumBackLogCalcVO.setcumbackmar14Mar20(cumBackLogCalcVO.getcumbackmar07Mar13().add(backLogCalcVO.getBackmar14Mar20()));
						
						cumBackLogCalcVO.setcumbackmar21Mar27(cumBackLogCalcVO.getcumbackmar14Mar20().add(backLogCalcVO.getBackmar21Mar27()));
						
						cumBackLogCalcVO.setcumbackmar28Apr03((cumBackLogCalcVO.getcumbackmar21Mar27().add(backLogCalcVO.getBackmar28Apr03())));
											
						cumBackLogCalcVO.setcumbackapr04Apr10((cumBackLogCalcVO.getcumbackmar28Apr03().add(backLogCalcVO.getBackapr04Apr10())));
						
						cumBackLogCalcVO.setcumbackapr11Apr17((cumBackLogCalcVO.getcumbackapr04Apr10().add(backLogCalcVO.getBackapr11Apr17())));
						
						cumBackLogCalcVO.setcumbackapr18Apr24((cumBackLogCalcVO.getcumbackapr11Apr17().add(backLogCalcVO.getBackapr18Apr24())));
						
						cumBackLogCalcVO.setcumbackapr25May01(cumBackLogCalcVO.getcumbackapr18Apr24().add(backLogCalcVO.getBackapr25May01()));
						
						cumBackLogCalcVO.setcumbackmay02May08(cumBackLogCalcVO.getcumbackapr25May01().add(backLogCalcVO.getBackmay02May08()));
						
						cumBackLogCalcVO.setcumbackmay09May15(cumBackLogCalcVO.getcumbackmay02May08().add(backLogCalcVO.getBackmay09May15()));
						
						cumBackLogCalcVO.setcumbackmay16May22(cumBackLogCalcVO.getcumbackmay09May15().add(backLogCalcVO.getBackmay16May22()));
						
						cumBackLogCalcVO.setcumbackmay23May29(cumBackLogCalcVO.getcumbackmay16May22().add(backLogCalcVO.getBackmay23May29()));
						
						cumBackLogCalcVO.setcumbackmay30Jul03(cumBackLogCalcVO.getcumbackmay23May29().add(backLogCalcVO.getBackmay30Jul03()));
						
						cumBackLogCalcVO.setcumbackjul04Jul31(cumBackLogCalcVO.getcumbackmay30Jul03().add(backLogCalcVO.getBackjul04Jul31()));
						
						cumBackLogCalcVO.setcumbackaug01Aug28(cumBackLogCalcVO.getcumbackjul04Jul31().add(backLogCalcVO.getBackaug01Aug28()));
						
						cumBackLogCalcVO.setcumbackaug29Oct02(cumBackLogCalcVO.getcumbackaug01Aug28().add(backLogCalcVO.getBackaug29Oct02()));
						
						cumBackLogCalcVO.setcumbackoct03Oct30(cumBackLogCalcVO.getcumbackaug29Oct02().add(backLogCalcVO.getBackoct03Oct30()));
						
						cumBackLogCalcVO.setcumbackoct31Nov27(cumBackLogCalcVO.getcumbackoct03Oct30().add(backLogCalcVO.getBackoct31Nov27()));
						
						cumBackLogCalcVO.setcumbacknov28Jan01(cumBackLogCalcVO.getcumbackoct31Nov27().add(backLogCalcVO.getBacknov28Jan01()));
						
						cumBackLogCalcVO.setcumbackjan02Jan29(cumBackLogCalcVO.getcumbacknov28Jan01().add(backLogCalcVO.getBackjan02Jan29()));
						
						cumBackLogCalcVO.setcumbackjan30Feb26(cumBackLogCalcVO.getcumbackjan02Jan29().add(backLogCalcVO.getBackjan30Feb26()));
						
						//setting the details to MAIN vo
						
						demandVo.setApr04Apr10(cumBackLogCalcVO.getcumbackapr04Apr10());
						demandVo.setApr11Apr17(cumBackLogCalcVO.getcumbackapr11Apr17());
						demandVo.setApr18Apr24(cumBackLogCalcVO.getcumbackapr18Apr24());
						demandVo.setApr25May01(cumBackLogCalcVO.getcumbackapr25May01());
						demandVo.setAug01Aug28(cumBackLogCalcVO.getcumbackaug01Aug28());
						demandVo.setAug29Oct02(cumBackLogCalcVO.getcumbackaug29Oct02());
						demandVo.setFeb29Mar06(cumBackLogCalcVO.getcumbackfeb29Mar06());
						demandVo.setJan02Jan29(cumBackLogCalcVO.getcumbackjan02Jan29());
						demandVo.setJan30Feb26(cumBackLogCalcVO.getcumbackjan30Feb26());
						demandVo.setJul04Jul31(cumBackLogCalcVO.getcumbackjul04Jul31());
						demandVo.setMar07Mar13(cumBackLogCalcVO.getcumbackmar07Mar13());
						demandVo.setMar14Mar20(cumBackLogCalcVO.getcumbackmar14Mar20());
						demandVo.setMar21Mar27(cumBackLogCalcVO.getcumbackmar21Mar27());
						demandVo.setMar28Apr03((cumBackLogCalcVO.getcumbackmar28Apr03()));
						demandVo.setMay02May08(cumBackLogCalcVO.getcumbackmay02May08());
						demandVo.setMay09May15(cumBackLogCalcVO.getcumbackmay09May15());
						demandVo.setMay16May22(cumBackLogCalcVO.getcumbackmay16May22());
						demandVo.setMay23May29(cumBackLogCalcVO.getcumbackmay23May29());
						demandVo.setMay30Jul03(cumBackLogCalcVO.getcumbackmay30Jul03());
						demandVo.setNov28Jan01(cumBackLogCalcVO.getcumbacknov28Jan01());
						demandVo.setOct03Oct30(cumBackLogCalcVO.getcumbackoct03Oct30());
						demandVo.setOct31Nov27(cumBackLogCalcVO.getcumbackoct31Nov27());
						demandVo.setPastDue(cumBackLogCalcVO.getcumbackpastDue());
						
						
					}else{
						demandVo.setApr11Apr17(demands.getApr11Apr17());
						demandVo.setApr18Apr24(demands.getApr18Apr24());
						demandVo.setApr25May01(demands.getApr25May01());
						demandVo.setAug01Aug28(demands.getAug01Aug28());
						demandVo.setAug29Oct02(demands.getAug29Oct02());
						demandVo.setFeb29Mar06(demands.getFeb29Mar06());
						demandVo.setJan02Jan29(demands.getJan02Jan29());
						demandVo.setJan30Feb26(demands.getJan30Feb26());
						demandVo.setJul04Jul31(demands.getJul04Jul31());
						demandVo.setMar07Mar13(demands.getMar07Mar13());
						demandVo.setMar14Mar20(demands.getMar14Mar20());
						demandVo.setMar21Mar27(demands.getMar21Mar27());
						demandVo.setMar28Apr03((demands.getMar28Apr03()));
						demandVo.setMay02May08(demands.getMay02May08());
						demandVo.setMay09May15(demands.getMay09May15());
						demandVo.setMay16May22(demands.getMay16May22());
						demandVo.setMay23May29(demands.getMay23May29());
						demandVo.setMay30Jul03(demands.getMay30Jul03());
						demandVo.setNov28Jan01(demands.getNov28Jan01());
						demandVo.setOct03Oct30(demands.getOct03Oct30());
						demandVo.setOct31Nov27(demands.getOct31Nov27());
						demandVo.setApr04Apr10(demands.getApr04Apr10());
					}
					
					
					
					/*demandVo.setApr04Apr10(demands.getApr04Apr10());
					demandVo.setApr11Apr17(demands.getApr11Apr17());
					demandVo.setApr18Apr24(demands.getApr18Apr24());
					demandVo.setApr25May01(demands.getApr25May01());
					demandVo.setAug01Aug28(demands.getAug01Aug28());
					demandVo.setAug29Oct02(demands.getAug29Oct02());
					demandVo.setFeb29Mar06(demands.getFeb29Mar06());
					demandVo.setJan02Jan29(demands.getJan02Jan29());
					demandVo.setJan30Feb26(demands.getJan30Feb26());
					demandVo.setJul04Jul31(demands.getJul04Jul31());
					demandVo.setMar07Mar13(demands.getMar07Mar13());
					demandVo.setMar14Mar20(demands.getMar14Mar20());
					demandVo.setMar21Mar27(demands.getMar21Mar27());
					demandVo.setMar28Apr03((demands.getMar28Apr03()));
					demandVo.setMay02May08(demands.getMay02May08());
					demandVo.setMay09May15(demands.getMay09May15());
					demandVo.setMay16May22(demands.getMay16May22());
					demandVo.setMay23May29(demands.getMay23May29());
					demandVo.setMay30Jul03(demands.getMay30Jul03());
					demandVo.setNov28Jan01(demands.getNov28Jan01());
					demandVo.setOct03Oct30(demands.getOct03Oct30());
					demandVo.setOct31Nov27(demands.getOct31Nov27());*/
					
					demandVo.setDemandId(demands.getDemandId());
					demandVo.setSentFlag(demands.getSentFlag());
					demandVo.setEditFlag(demands.getEditFlag());
					
					//demandDateVoList.add(dateVO);
					//quantityTypeVO.setDemandDateVos(demandDateVoList);
					//quantityVoList.add(quantityTypeVO);
					//demandVo.setQuantityVos(quantityVoList);
					demandVos.add(demandVo);
					
				}
				
				
				}


			 catch (Exception e) {
				System.out.println("HospitalAlarmService.getDemandDetailsWithOutFilter()" + e);
			}
			return demandVos;
	
	}
}
