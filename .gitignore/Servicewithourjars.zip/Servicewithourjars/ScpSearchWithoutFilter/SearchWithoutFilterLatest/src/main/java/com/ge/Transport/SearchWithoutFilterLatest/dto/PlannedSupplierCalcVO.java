package com.ge.Transport.SearchWithoutFilterLatest.dto;

import java.math.BigDecimal;

public class PlannedSupplierCalcVO {

	
	private BigDecimal backapr04Apr10;

	private BigDecimal backapr11Apr17;

	private BigDecimal backapr18Apr24;

	private BigDecimal backapr25May01;

	private BigDecimal backaug01Aug28;

	private BigDecimal backaug29Oct02;

	private BigDecimal backoct31Nov27;

	private BigDecimal backfeb29Mar06;

	private BigDecimal backjan02Jan29;

	private BigDecimal backjan30Feb26;

	private BigDecimal backjul04Jul31;

	private BigDecimal backmar07Mar13;

	private BigDecimal backmar14Mar20;

	private BigDecimal backmar21Mar27;

	private BigDecimal backmar28Apr03;

	private BigDecimal backmay02May08;

	private BigDecimal backmay09May15;

	private BigDecimal backmay16May22;

	private BigDecimal backmay23May29;

	private BigDecimal backmay30Jul03;
	
	private BigDecimal backnov28Jan01;

	private BigDecimal backoct03Oct30;
	
	private String quantityType;
	
	private BigDecimal demandId;
	
	private String editFlag;
	
	private String sentFlag;
	
	private BigDecimal backpastDue;
		

	public BigDecimal getBackapr04Apr10() {
		return backapr04Apr10;
	}

	public void setBackapr04Apr10(BigDecimal backapr04Apr10) {
		this.backapr04Apr10 = backapr04Apr10;
	}

	public BigDecimal getBackapr11Apr17() {
		return backapr11Apr17;
	}

	public void setBackapr11Apr17(BigDecimal backapr11Apr17) {
		this.backapr11Apr17 = backapr11Apr17;
	}

	public BigDecimal getBackapr18Apr24() {
		return backapr18Apr24;
	}

	public void setBackapr18Apr24(BigDecimal backapr18Apr24) {
		this.backapr18Apr24 = backapr18Apr24;
	}

	public BigDecimal getBackapr25May01() {
		return backapr25May01;
	}

	public void setBackapr25May01(BigDecimal backapr25May01) {
		this.backapr25May01 = backapr25May01;
	}

	public BigDecimal getBackaug01Aug28() {
		return backaug01Aug28;
	}

	public void setBackaug01Aug28(BigDecimal backaug01Aug28) {
		this.backaug01Aug28 = backaug01Aug28;
	}

	public BigDecimal getBackaug29Oct02() {
		return backaug29Oct02;
	}

	public void setBackaug29Oct02(BigDecimal backaug29Oct02) {
		this.backaug29Oct02 = backaug29Oct02;
	}

	public BigDecimal getBackoct31Nov27() {
		return backoct31Nov27;
	}

	public void setBackoct31Nov27(BigDecimal backoct31Nov27) {
		this.backoct31Nov27 = backoct31Nov27;
	}

	public BigDecimal getBackfeb29Mar06() {
		return backfeb29Mar06;
	}

	public void setBackfeb29Mar06(BigDecimal backfeb29Mar06) {
		this.backfeb29Mar06 = backfeb29Mar06;
	}

	public BigDecimal getBackjan02Jan29() {
		return backjan02Jan29;
	}

	public void setBackjan02Jan29(BigDecimal backjan02Jan29) {
		this.backjan02Jan29 = backjan02Jan29;
	}

	public BigDecimal getBackjan30Feb26() {
		return backjan30Feb26;
	}

	public void setBackjan30Feb26(BigDecimal backjan30Feb26) {
		this.backjan30Feb26 = backjan30Feb26;
	}

	public BigDecimal getBackjul04Jul31() {
		return backjul04Jul31;
	}

	public void setBackjul04Jul31(BigDecimal backjul04Jul31) {
		this.backjul04Jul31 = backjul04Jul31;
	}

	public BigDecimal getBackmar07Mar13() {
		return backmar07Mar13;
	}

	public void setBackmar07Mar13(BigDecimal backmar07Mar13) {
		this.backmar07Mar13 = backmar07Mar13;
	}

	public BigDecimal getBackmar14Mar20() {
		return backmar14Mar20;
	}

	public void setBackmar14Mar20(BigDecimal backmar14Mar20) {
		this.backmar14Mar20 = backmar14Mar20;
	}

	public BigDecimal getBackmar21Mar27() {
		return backmar21Mar27;
	}

	public void setBackmar21Mar27(BigDecimal backmar21Mar27) {
		this.backmar21Mar27 = backmar21Mar27;
	}

	public BigDecimal getBackmar28Apr03() {
		return backmar28Apr03;
	}

	public void setBackmar28Apr03(BigDecimal backmar28Apr03) {
		this.backmar28Apr03 = backmar28Apr03;
	}

	public BigDecimal getBackmay02May08() {
		return backmay02May08;
	}

	public void setBackmay02May08(BigDecimal backmay02May08) {
		this.backmay02May08 = backmay02May08;
	}

	public BigDecimal getBackmay09May15() {
		return backmay09May15;
	}

	public void setBackmay09May15(BigDecimal backmay09May15) {
		this.backmay09May15 = backmay09May15;
	}

	public BigDecimal getBackmay16May22() {
		return backmay16May22;
	}

	public void setBackmay16May22(BigDecimal backmay16May22) {
		this.backmay16May22 = backmay16May22;
	}

	public BigDecimal getBackmay23May29() {
		return backmay23May29;
	}

	public void setBackmay23May29(BigDecimal backmay23May29) {
		this.backmay23May29 = backmay23May29;
	}

	public BigDecimal getBackmay30Jul03() {
		return backmay30Jul03;
	}

	public void setBackmay30Jul03(BigDecimal backmay30Jul03) {
		this.backmay30Jul03 = backmay30Jul03;
	}

	public BigDecimal getBacknov28Jan01() {
		return backnov28Jan01;
	}

	public void setBacknov28Jan01(BigDecimal backnov28Jan01) {
		this.backnov28Jan01 = backnov28Jan01;
	}

	public BigDecimal getBackoct03Oct30() {
		return backoct03Oct30;
	}

	public void setBackoct03Oct30(BigDecimal backoct03Oct30) {
		this.backoct03Oct30 = backoct03Oct30;
	}

	public String getQuantityType() {
		return quantityType;
	}

	public void setQuantityType(String quantityType) {
		this.quantityType = quantityType;
	}

	public BigDecimal getDemandId() {
		return demandId;
	}

	public void setDemandId(BigDecimal demandId) {
		this.demandId = demandId;
	}

	public String getEditFlag() {
		return editFlag;
	}

	public void setEditFlag(String editFlag) {
		this.editFlag = editFlag;
	}

	public String getSentFlag() {
		return sentFlag;
	}

	public void setSentFlag(String sentFlag) {
		this.sentFlag = sentFlag;
	}

	public BigDecimal getBackpastDue() {
		return backpastDue;
	}

	public void setBackpastDue(BigDecimal backpastDue) {
		this.backpastDue = backpastDue;
	}
	
}
