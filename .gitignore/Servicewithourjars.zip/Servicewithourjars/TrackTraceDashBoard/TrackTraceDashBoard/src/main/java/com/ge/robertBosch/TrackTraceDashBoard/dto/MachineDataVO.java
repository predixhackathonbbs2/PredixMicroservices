package com.ge.robertBosch.TrackTraceDashBoard.dto;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Lob;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class MachineDataVO {
	
	private long processId;

	private String data;

	public long getProcessId() {
		return processId;
	}

	public void setProcessId(long processId) {
		this.processId = processId;
	}

	

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public BigDecimal getTighteingid() {
		return tighteingid;
	}

	public void setTighteingid(BigDecimal tighteingid) {
		this.tighteingid = tighteingid;
	}

	private BigDecimal tighteingid;


}

