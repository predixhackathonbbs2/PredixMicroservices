package com.ge.robertBosch.TrackTraceDashBoard.repository;

/** Copyright (c) 2013 GE Global Research. All rights reserved.
*
* The copyright to the computer software herein is the property of
* GE Global Research. The software may be used and/or copied only
* with the written permission of GE Global Research or in accordance
* with the terms and conditions stipulated in the agreement/contract
* under which the software has been supplied.
*/

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ge.robertBosch.TrackTraceDashBoard.entity.M2mDevice;

/**
* This class models the spring-data repository for alarmevent entity. Apart form the standard operations supported by
* CRUD Repository, this class also supports customized named queries ,pagination, sorting and type safe queries using query-dsl.
* 
* @author 212350258
*/
@Repository
public interface IM2MDeviceRepository extends JpaRepository<M2mDevice, Integer>
{
	
	String GET_TOOLFLEET_COUNT = "select count(*) from M2mDevice a ";
	
	String GET_DEVICE_DETAILS = "select a.model as model, a.name as name,a.connection as connection,a.status as status,b.accuracy as accuracy,b.x as x ,"
			+ "b.y as y,b.zone as zone,c.tighteingid as tighteingid,c.tighteningstatus as tighteningstatus,c.tighteningprogrambigint as tighteningprogrambigint,a.serialno as serialno,"
			+ "a.type as type"
			+ " from M2mDevice a,M2mDevicepostn b,M2mResult c"
			+ " where a.id=b.m2mDevice.id and a.id=c.m2mDevice.id"
			+ " and a.id=?1";
	
	@Override
	public List<M2mDevice> findAll();
	
	@Query(GET_TOOLFLEET_COUNT)
	public Integer getToolFleetCount();
	
	
	@Query(GET_DEVICE_DETAILS)
	List<Object []> getDeviceDetailsById(Long deviceId);
	
	
	
	
	
}