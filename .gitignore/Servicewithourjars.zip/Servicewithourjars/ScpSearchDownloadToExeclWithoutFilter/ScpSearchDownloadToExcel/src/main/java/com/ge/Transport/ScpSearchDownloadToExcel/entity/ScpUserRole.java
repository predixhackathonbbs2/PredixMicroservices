package com.ge.Transport.ScpSearchDownloadToExcel.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the SCP_USER_ROLE database table.
 * 
 */
@Entity
@Table(name="SCP_USER_ROLE")
@NamedQuery(name="ScpUserRole.findAll", query="SELECT s FROM ScpUserRole s")
public class ScpUserRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SCP_USER_ROLE_ROLEID_GENERATOR", sequenceName="SCP_DETAILS")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SCP_USER_ROLE_ROLEID_GENERATOR")
	@Column(name="ROLE_ID")
	private long roleId;

	@Column(name="ROLE_NAME")
	private String roleName;

	//bi-directional many-to-one association to ScpUser
	@OneToMany(mappedBy="scpUserRole")
	private List<ScpUser> scpUsers;

	public ScpUserRole() {
	}

	public long getRoleId() {
		return this.roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return this.roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public List<ScpUser> getScpUsers() {
		return this.scpUsers;
	}

	public void setScpUsers(List<ScpUser> scpUsers) {
		this.scpUsers = scpUsers;
	}

	public ScpUser addScpUser(ScpUser scpUser) {
		getScpUsers().add(scpUser);
		scpUser.setScpUserRole(this);

		return scpUser;
	}

	public ScpUser removeScpUser(ScpUser scpUser) {
		getScpUsers().remove(scpUser);
		scpUser.setScpUserRole(null);

		return scpUser;
	}

}
