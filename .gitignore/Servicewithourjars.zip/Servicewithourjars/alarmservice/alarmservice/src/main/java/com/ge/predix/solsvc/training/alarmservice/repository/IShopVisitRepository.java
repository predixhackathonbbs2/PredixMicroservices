package com.ge.predix.solsvc.training.alarmservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ge.predix.solsvc.training.alarmservice.entity.ShopVisit;

public interface IShopVisitRepository extends JpaRepository<ShopVisit, Long>{
	
	String FIND_BY_ESN = "select sv.amount,sv.dateOfVisit from ShopVisit sv,Engines en where sv.engineShopvisit.esn=?1 order by sv.dateOfVisit";

	List<ShopVisit> findByEngineShopvisitEsn(String esnNumber);

	@Query(FIND_BY_ESN)
	List<Object[]> findShopVisitByEsn(String esnNumber);

}

