package com.ge.predix.solsvc.training.alarmservice.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import java.util.Set;

@Entity
@Table(name = "Model")
public class Models  implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="MODEL_ID_GENERATOR" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="MODEL_ID_GENERATOR")
	private long id;

	@Column(name="MODEL_NAME")
	private String modelName;

	@Column(name="MODEL_NUMBER")
	private String modelNumber;

	//bi-directional many-to-one association to Engine
	@OneToMany(fetch = FetchType.LAZY,mappedBy="models")
	private Set<Engines> engines;

	public Models() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getModelName() {
		return this.modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getModelNumber() {
		return this.modelNumber;
	}

	public void setModelNumber(String modelNumber) {
		this.modelNumber = modelNumber;
	}

	public Set<Engines> getEngines() {
		return this.engines;
	}

	public void setEngines(Set<Engines> engines) {
		this.engines = engines;
	}

	/*public Engine addEngine(Engine engine) {
		getEngines().add(engine);
		engine.setModel(this);

		return engine;
	}

	public Engine removeEngine(Engine engine) {
		getEngines().remove(engine);
		engine.setModel(null);

		return engine;
	}*/

}
