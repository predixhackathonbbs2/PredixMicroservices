package com.ge.predix.solsvc.training.alarmservice.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ShopVisitVO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private long id;   
	private BigDecimal amount;
	private long dateOfVisit;
	private String noOfCyclesSinceLastVisit;
	private String noOfCyclesSinceNew;
	private String workscope;
	
	
	//private EngineVO engine;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	
	public String getNoOfCyclesSinceLastVisit() {
		return noOfCyclesSinceLastVisit;
	}
	public void setNoOfCyclesSinceLastVisit(String noOfCyclesSinceLastVisit) {
		this.noOfCyclesSinceLastVisit = noOfCyclesSinceLastVisit;
	}
	public String getNoOfCyclesSinceNew() {
		return noOfCyclesSinceNew;
	}
	public void setNoOfCyclesSinceNew(String noOfCyclesSinceNew) {
		this.noOfCyclesSinceNew = noOfCyclesSinceNew;
	}
	public String getWorkscope() {
		return workscope;
	}
	public void setWorkscope(String workscope) {
		this.workscope = workscope;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public long getDateOfVisit() {
		return dateOfVisit;
	}
	public void setDateOfVisit(long dateOfVisit) {
		this.dateOfVisit = dateOfVisit;
	}


}

