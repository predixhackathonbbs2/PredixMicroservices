package com.ge.predix.solsvc.training.alarmservice.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ge.predix.solsvc.training.alarmservice.entity.Parts;

public interface IPartsRepository  extends  CrudRepository<Parts, Long>{
	
	List<Parts> findByEnginepartEsn(String esnNumber);	

}
