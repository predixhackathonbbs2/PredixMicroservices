package com.ge.predix.solsvc.training.alarmservice.jpa.init;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.predix.solsvc.training.alarmservice.entity.AlarmEventEntity;
import com.ge.predix.solsvc.training.alarmservice.entity.Engines;
import com.ge.predix.solsvc.training.alarmservice.entity.Models;
import com.ge.predix.solsvc.training.alarmservice.entity.Parts;
import com.ge.predix.solsvc.training.alarmservice.entity.PatientEntity;
import com.ge.predix.solsvc.training.alarmservice.entity.ShopVisit;
import com.ge.predix.solsvc.training.alarmservice.repository.IAlarmEventEntityRepository;
import com.ge.predix.solsvc.training.alarmservice.repository.IEngineEntityRepository;
import com.ge.predix.solsvc.training.alarmservice.repository.IModelRepository;
import com.ge.predix.solsvc.training.alarmservice.repository.IPartsRepository;
import com.ge.predix.solsvc.training.alarmservice.repository.IPatientEntityRepository;
import com.ge.predix.solsvc.training.alarmservice.repository.IShopVisitRepository;
import com.ge.predix.solsvc.training.enums.WorkScope;
import com.ge.predix.util.RandomUtils;

@Component
public class InitAlarmServiceData {
	
	@Autowired
	private IAlarmEventEntityRepository alarmService;

	@Autowired
	private IPatientEntityRepository patientService;
	
	@Autowired
	private IModelRepository modelService;
	
	@Autowired
	private IEngineEntityRepository engineService;
	
	
	@Autowired
	private IPartsRepository partService;
	
	
	@Autowired
	private IShopVisitRepository shopService;
	
	
	
	
	
	/*@Autowired
	private IHospitalEntityRepository hospitalRepo;
	*/
	
	@PostConstruct
	public void initAlarmServiceData(){
		/*HospitalEntity he = new HospitalEntity();
		he.setAddress("100, 2305 Camino Ramon, San Ramon, CA 94583");
		he.setPhone("925 234 2345");
		he.setName("John Muir Medical Group");
		he.setEmail("mike.waldman@ge.com");
		hospitalRepo.save(he);*/
		
		PatientEntity pe = new PatientEntity(1, "Mike", "", "Waldman", "mike.waldman@ge.com", "", null);
		patientService.save(pe);
		
		List<AlarmEventEntity> eList = new ArrayList<AlarmEventEntity>();
		AlarmEventEntity e = new AlarmEventEntity(1, "ARTIFACT", "TECHNICAL", 1);
		eList.add(e);
		e = new AlarmEventEntity(1, "PVC", "ARRHYTHMIA", 4);
		eList.add(e);
		e = new AlarmEventEntity(1, "COUPLET", "ARRHYTHMIA", 4);
		eList.add(e);
		e = new AlarmEventEntity(1, "PVC", "ARRHYTHMIA", 4);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 PROBE", "TECHNICAL", 2);
		eList.add(e);
		e = new AlarmEventEntity(1, "COUPLET", "ARRHYTHMIA", 4);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 PROBE", "TECHNICAL", 2);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 MOTION DET", "TECHNICAL", 0);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 MOTION DET", "TECHNICAL", 0);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 PROBE", "TECHNICAL", 2);
		eList.add(e);
		e = new AlarmEventEntity(1, "ARTIFACT", "TECHNICAL", 1);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 PROBE", "TECHNICAL", 2);
		eList.add(e);
		e = new AlarmEventEntity(1, "ARTIFACT", "TECHNICAL", 1);
		eList.add(e);
		e = new AlarmEventEntity(1, "PVC", "ARRHYTHMIA", 4);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 PROBE", "TECHNICAL", 2);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 LO", "PARAMETER", 6);
		eList.add(e);
		e = new AlarmEventEntity(1, "ARTIFACT", "TECHNICAL", 1);
		eList.add(e);
		e = new AlarmEventEntity(1, "PVC", "ARRHYTHMIA", 4);
		eList.add(e);
		e = new AlarmEventEntity(1, "CHNGE BATTERY", "TECHNICAL", 2);
		eList.add(e);
		e = new AlarmEventEntity(1, "ARTIFACT", "TECHNICAL", 1);
		eList.add(e);
		e = new AlarmEventEntity(1, "ARTIFACT", "TECHNICAL", 1);
		eList.add(e);
		e = new AlarmEventEntity(1, "ARTIFACT", "TECHNICAL", 1);
		eList.add(e);
		e = new AlarmEventEntity(1, "PVC", "ARRHYTHMIA", 4);
		eList.add(e);
		e = new AlarmEventEntity(1, "ARTIFACT", "TECHNICAL", 1);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 LO", "PARAMETER", 6);
		eList.add(e);
		e = new AlarmEventEntity(1, "ARTIFACT", "TECHNICAL", 1);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 MOTION DET", "TECHNICAL", 0);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 MOTION DET", "TECHNICAL", 0);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 PROBE", "TECHNICAL", 2);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 LO", "PARAMETER", 6);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 LO", "PARAMETER", 6);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 LO", "PARAMETER", 6);
		eList.add(e);
		e = new AlarmEventEntity(1, "ARTIFACT", "TECHNICAL", 1);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 LO", "PARAMETER", 6);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 LO", "PARAMETER", 6);
		eList.add(e);
		e = new AlarmEventEntity(1, "SPO2 LO", "PARAMETER", 6);
		eList.add(e);	
		//alarmService.save(eList);
		
		
		Models models = new Models();
		List<Models> mList =new ArrayList<Models>();
		models.setId(774);
		models.setModelName("PRITHVI");
		models.setModelNumber("CRM-110");
		
		
		Models models1 = new Models();
		models1.setId(770);
		models1.setModelName("VAYU");
		models1.setModelNumber("CRM-552");
		
		Models models2 = new Models();
		models2.setId(771);
		models2.setModelName("PRITHVI");
		models2.setModelNumber("CRM-810");
		
		Models models3 = new Models();
		models3.setId(773);
		models3.setModelName("AGNI");
		models3.setModelNumber("CRM-223");
		
		mList.add(models);
		mList.add(models1);
		mList.add(models2);
		mList.add(models3);
		//modelService.save(mList);
		
		List<Models> engineModels = modelService.findAll();
		for (Models engineModel : engineModels) {
			for (int j = 0; j < 4; j++) {
				Engines engine = new Engines();
				engine.setEsn(RandomStringUtils.randomNumeric(6));
				engine.setModels(engineModel);
				engineService.save(engine);
			}

		}
		
		List<String> partNames=new ArrayList<String>();
		partNames.add("ASSY - COMBUSTION CHAMBER");
		partNames.add("FUEL SYSTEM COMPONENTS");
		partNames.add("ASSY - FAN ROTOR");
		partNames.add("ASSY - HPC ROTOR");
		partNames.add("SUPPORT - BEARING");
		partNames.add("BLADE - FAN");
		partNames.add("LINK - THRUST ENGINE MOUNT");
		partNames.add("SEAL - CDP");
		partNames.add("HOUSING - BEARING NO 1");
		partNames.add("ELECTRICAL - TRANSMITTER");
		partNames.add("PLATE - HPT COOLING");
		partNames.add("SPOOL");
		partNames.add("CASE - LPT");
		partNames.add("ALTERNATOR - GENERATOR STATOR/ROTOR");
		partNames.add("FRAME - EXHAUST");
		partNames.add("CASE - FAN BLADE CONTAINMENT");
		partNames.add("MISC - LOW COST PARTS");
		partNames.add("SENSOR - SENSOR N1 & N2 SPEED");
		partNames.add("ASSY - HPC STATOR");
		partNames.add("DISK - FAN STG 1");
		partNames.add("SHAFT - LPT");
		partNames.add("PUMP - LUBE");
		partNames.add("BLADE - HPT STG 1");
		partNames.add("Blisk - HPC");
		partNames.add("ACTUATOR");
		partNames.add("SEAL - HPC");
		partNames.add("SEAL - TURBINE STG 3 & 4");
		partNames.add("ASSY - ACCESSORY GEARBOX");
		partNames.add("CASE - HPC");
		partNames.add("SEAL - TURBINE STG 5 & 6");
		partNames.add("VALVE");
		partNames.add("ASSY - LPT MODULE");
		partNames.add("BEARING - MAIN #1");
		partNames.add("ASSY - PTO DRIVE");
		partNames.add("MOUNT - ENGINE");
		partNames.add("DISK - HPT STG 1");
		partNames.add("LINER - COMBUSTION");
		partNames.add("DISK - LPT STG 3");
		partNames.add("DISK - LPT STG 4");
		partNames.add("PLUG");
		partNames.add("SEAL - ROTATING AIR");
		partNames.add("SEAL - AIR");
		partNames.add("Blisk - HPC");
		partNames.add("SUPPORT - MOUNT BEAM");
		partNames.add("SEAL - AIR BALANCE PISTON ST");
		partNames.add("ASSY - DOME COMBUSTION");
		partNames.add("NOZZLE - HPT STG 1");
		partNames.add("FRAME - FAN HUB");
		partNames.add("DISK - LPT STG 5");
		partNames.add("COUPLING");
		partNames.add("DISK - HPT STG 2");
		
		List<Engines> engines = (List<Engines>) engineService.findAll();
		Parts partDtls =null;
		Set<Parts> partSet = new HashSet<Parts>();
		System.out.println("InitAlarmServiceData.initAlarmServiceData() partName  size ---------> " + partNames.size());
		System.out.println("InitAlarmServiceData.initAlarmServiceData() Engine details size *****  -> " + engines.size());
		for(Engines engine:engines){
			for (int i = 0; i < partNames.size(); i++) {
				partDtls = new Parts();
				partDtls.setPartSerialNumber(RandomStringUtils.randomAlphanumeric(6));
				partDtls.setIin(RandomStringUtils.randomNumeric(3));
				partDtls.setPartCycleSinceNew(null);
				partDtls.setPartNumber(org.apache.commons.lang.math.RandomUtils.nextInt(4)+RandomStringUtils.randomAlphanumeric(3)+""+i);
				partDtls.setPartName(partNames.get(i));
				partDtls.setCatalogPrice(BigDecimal.valueOf(RandomUtils.randomLongBetween(6000l,100000l)));
				partDtls.setEnginepart(engine);
				partSet.add(partDtls);
				engine.setParts(partSet);
				//partService.save(partDtls);
			}
			
		}
		
		
		for (Engines engine : engines) {
			int visitCount = RandomUtils.randomIntgerBetween(5, 10);
			String noOfCyclesSinceNew=RandomStringUtils.randomNumeric(5);
			for (int j = 0; j < visitCount; j++) {
				ShopVisit shopvisit = new ShopVisit();
				shopvisit.setEngineShopvisit(engine);
				shopvisit.setNoOfCyclesSinceNew(noOfCyclesSinceNew);
				Long engineCycleSinceNew=Long.parseLong(shopvisit.getNoOfCyclesSinceNew());
				Long engineCycleSinceLastSV=Long.parseLong(RandomStringUtils.randomNumeric(5));
				Long numberOfCyclesSinceLastSV=0l;
				if(engineCycleSinceLastSV>engineCycleSinceNew){
					numberOfCyclesSinceLastSV=engineCycleSinceLastSV-engineCycleSinceNew;
				}
				else{
					numberOfCyclesSinceLastSV=engineCycleSinceNew-engineCycleSinceLastSV;
				}
				shopvisit.setNoOfCyclesSinceLastVisit(numberOfCyclesSinceLastSV.toString());
				shopvisit.setDateOfVisit(RandomUtils.randomDateBetween(2013, 2014));
				shopvisit.setWorkscope(WorkScope.values()[new Random().nextInt(WorkScope.values().length)].toString());
				shopvisit.setAmount(new BigDecimal(RandomStringUtils.randomNumeric(4)));
				//shopService.save(shopvisit);
			}
		}
		
		
	}
	
}
