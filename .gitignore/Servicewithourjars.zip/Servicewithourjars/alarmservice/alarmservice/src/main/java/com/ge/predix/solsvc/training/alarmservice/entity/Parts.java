package com.ge.predix.solsvc.training.alarmservice.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="PARTS")
public class Parts implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PARTS_ID_GENERATOR" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PARTS_ID_GENERATOR")
	private long id;

	@Column(name="CATALOG_PRICE")
	private BigDecimal catalogPrice;
    
	@Column(name="CATEGORY")
	private String category;

	@Column(name="IIN")
	private String iin;

	@Column(name="LIFE_REMAINING_PERCENT")
	private String lifeRemainingPercent;

	@Column(name="LLP_IND")
	private String llpInd;

	@Column(name="MINOR_MODULE")
	private String minorModule;

	@Column(name="PART_CYCLE_REMAINING")
	private BigDecimal partCycleRemaining;

	@Column(name="PART_CYCLE_SINCE_NEW")
	private BigDecimal partCycleSinceNew;

	@Column(name="PART_LLP_CYCLE")
	private BigDecimal partLlpCycle;

	@Column(name="PART_NAME")
	private String partName;

	@Column(name="PART_NUMBER")
	private String partNumber;

	@Column(name="PART_SERIAL_NUMBER")
	private String partSerialNumber;

	@Column(name="QPE")
	private String qpe;

	//bi-directional many-to-one association to Engine
	@ManyToOne
	@JoinColumn(name = "ENGINE_ID")
	private Engines enginepart;

	public Parts() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public BigDecimal getCatalogPrice() {
		return this.catalogPrice;
	}

	public void setCatalogPrice(BigDecimal catalogPrice) {
		this.catalogPrice = catalogPrice;
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getIin() {
		return this.iin;
	}

	public void setIin(String iin) {
		this.iin = iin;
	}

	public String getLifeRemainingPercent() {
		return this.lifeRemainingPercent;
	}

	public void setLifeRemainingPercent(String lifeRemainingPercent) {
		this.lifeRemainingPercent = lifeRemainingPercent;
	}

	public String getLlpInd() {
		return this.llpInd;
	}

	public void setLlpInd(String llpInd) {
		this.llpInd = llpInd;
	}

	public String getMinorModule() {
		return this.minorModule;
	}

	public void setMinorModule(String minorModule) {
		this.minorModule = minorModule;
	}

	public BigDecimal getPartCycleRemaining() {
		return this.partCycleRemaining;
	}

	public void setPartCycleRemaining(BigDecimal partCycleRemaining) {
		this.partCycleRemaining = partCycleRemaining;
	}

	public BigDecimal getPartCycleSinceNew() {
		return this.partCycleSinceNew;
	}

	public void setPartCycleSinceNew(BigDecimal partCycleSinceNew) {
		this.partCycleSinceNew = partCycleSinceNew;
	}

	public BigDecimal getPartLlpCycle() {
		return this.partLlpCycle;
	}

	public void setPartLlpCycle(BigDecimal partLlpCycle) {
		this.partLlpCycle = partLlpCycle;
	}

	public String getPartName() {
		return this.partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}

	public String getPartNumber() {
		return this.partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getPartSerialNumber() {
		return this.partSerialNumber;
	}

	public void setPartSerialNumber(String partSerialNumber) {
		this.partSerialNumber = partSerialNumber;
	}

	public String getQpe() {
		return this.qpe;
	}

	public void setQpe(String qpe) {
		this.qpe = qpe;
	}

	public Engines getEnginepart() {
		return enginepart;
	}

	public void setEnginepart(Engines enginepart) {
		this.enginepart = enginepart;
	}
	
	
	
/*	public Engine getEngine() {
		return this.engine;
	}

	public void setEngine(Engine engine) {
		this.engine = engine;
	}*/


}
