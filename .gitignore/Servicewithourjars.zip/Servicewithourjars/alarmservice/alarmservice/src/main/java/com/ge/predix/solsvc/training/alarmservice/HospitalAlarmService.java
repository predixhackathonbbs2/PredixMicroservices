package com.ge.predix.solsvc.training.alarmservice;

import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.commons.lang.RandomStringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.predix.solsvc.training.alarmservice.dto.AlarmEvent;
import com.ge.predix.solsvc.training.alarmservice.dto.EngineVO;
import com.ge.predix.solsvc.training.alarmservice.dto.ModelVO;
import com.ge.predix.solsvc.training.alarmservice.dto.OEE_Equipment;
import com.ge.predix.solsvc.training.alarmservice.dto.PartVO;
import com.ge.predix.solsvc.training.alarmservice.entity.AlarmEventEntity;
import com.ge.predix.solsvc.training.alarmservice.entity.Engines;
import com.ge.predix.solsvc.training.alarmservice.entity.Models;
import com.ge.predix.solsvc.training.alarmservice.entity.OEE_Equipment_Entity_Dtl;
import com.ge.predix.solsvc.training.alarmservice.entity.Parts;
import com.ge.predix.solsvc.training.alarmservice.entity.ShopVisit;
import com.ge.predix.solsvc.training.alarmservice.repository.IAlarmEventEntityRepository;
import com.ge.predix.solsvc.training.alarmservice.repository.IEngineEntityRepository;
import com.ge.predix.solsvc.training.alarmservice.repository.IModelRepository;
import com.ge.predix.solsvc.training.alarmservice.repository.IOEEEntityRepository;
import com.ge.predix.solsvc.training.alarmservice.repository.IPartsRepository;
import com.ge.predix.solsvc.training.alarmservice.repository.IShopVisitRepository;
import com.ge.predix.solsvc.training.enums.WorkScope;
import com.ge.predix.util.RandomUtils;

@RestController
public class HospitalAlarmService {

	@Autowired
	private IAlarmEventEntityRepository alarmService;

	@Autowired
	private IModelRepository modelService;

	@Autowired
	private IEngineEntityRepository engineService;

	@Autowired
	private IPartsRepository partService;

	@Autowired
	private IShopVisitRepository shopVisitService;
	
	@Autowired
	private IOEEEntityRepository oeeRepository;

	@RequestMapping("/alarmservice")
	public @ResponseBody List<AlarmEvent> helloWorld() {
		List<AlarmEvent> events = new ArrayList<AlarmEvent>();
		List<AlarmEventEntity> entities = this.alarmService.findAll();
		for (AlarmEventEntity entity : entities) {
			events.add(entity.toAlarmEvent());
		}
		return events;
	}

	@RequestMapping("/models")
	public @ResponseBody List<ModelVO> getModelDetails() {
		List<ModelVO> modelVOs = new ArrayList<ModelVO>();
		ModelVO modelVO = null;
		// List<EngineVO> engineVOs = new ArrayList<EngineVO>();
		/*
		 * EngineVO engineVO = new EngineVO();
		 * 
		 * engineVOs.add(engineVO);
		 */
		try {
			List<Models> retList = modelService.findAll();

			for (Models model : retList) {
				modelVO = new ModelVO();
				modelVO.setId(model.getId());
				modelVO.setModelName(model.getModelName());
				modelVO.setModelNumber(model.getModelNumber());
				modelVOs.add(modelVO);
			}
			// modelVO.setEngines(engineVOs);

		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return modelVOs;
	}

	@RequestMapping("/engine/{modelNumber}")
	public @ResponseBody List<EngineVO> getEngineDetails(
			@PathVariable("modelNumber") String modelNumber) {
		List<EngineVO> engineVo = new ArrayList<EngineVO>();
		System.out
				.println("HospitalAlarmService.getEngineDetails() ------ ****> Model Number"
						+ modelNumber);

		try {
			List<Engines> engines = engineService
					.findByModelsModelNumber(modelNumber);
			EngineVO engineVO = null;
			for (Engines engine : engines) {
				engineVO = new EngineVO();
				engineVO.setEngineCycleSinceNew(engine.getEngineCycleSinceNew());
				engineVO.setEngineTimeSinceNew(engine.getEngineTimeSinceNew());
				engineVO.setEsn(engine.getEsn());
				engineVO.setId(engine.getId());
				engineVO.setSeriesId(engine.getSeriesId());
				engineVo.add(engineVO);

			}
			// modelVO.setEngines(engineVOs);

		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return engineVo;
	}

	@RequestMapping("/partsDetails/{esnNumber}")
	public @ResponseBody List<PartVO> getPartDetails(
			@PathVariable("esnNumber") String esnNumber) {
		System.out
				.println("HospitalAlarmService.getEngineDetails() ------ ****> esnNumber Number"
						+ esnNumber);

		List<PartVO> partVOS = new ArrayList<PartVO>();
		List<Parts> partLists = partService.findByEnginepartEsn(esnNumber);
		PartVO partVO = null;

		try {
			for (Parts partVos : partLists) {
				partVO = new PartVO();
				partVO.setCatalogPrice(partVos.getCatalogPrice());
				partVO.setCategory(partVos.getCategory());
				partVO.setId(partVos.getId());
				partVO.setIin(partVos.getIin());
				partVO.setLifeRemainingPercent(partVos
						.getLifeRemainingPercent());
				partVO.setLlpInd(partVos.getLlpInd());
				partVO.setMinorModule(partVos.getMinorModule());
				partVO.setPartCycleRemaining(partVos.getPartCycleRemaining());
				partVO.setPartCycleSinceNew(partVos.getPartCycleSinceNew());
				partVO.setPartLlpCycle(partVos.getPartLlpCycle());
				partVO.setPartName(partVos.getPartName());
				partVO.setPartNumber(partVos.getPartNumber());
				partVO.setPartSerialNumber(partVos.getPartSerialNumber());
				partVO.setQpe(partVos.getQpe());
				partVOS.add(partVO);
				
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return partVOS;
	}

	@RequestMapping("shopVisitDetailsByEsn/{esnNumber}")
	public @ResponseBody List<Map<String, Object>> findShopVisitByEsn(
			@PathVariable("esnNumber") String esnNumber) {
		System.out
				.println("HospitalAlarmService.findShopVisitByEsn() ******> esnNumber Number "
						+ esnNumber);

		List<Object[]> retList = shopVisitService.findShopVisitByEsn(esnNumber);
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Map<String, Object> objMap = null;
		for (int i = 0; i < retList.size(); i++) {
			objMap = new HashMap<String, Object>();
			objMap.put("amount", (retList.get(i))[0]);
			System.out.println("IShopVisitPersstenceImpl.findShopVisitByEsn()"
					+ ((Date) (retList.get(i))[1]).getTime());
			objMap.put("shopVisitDate", ((Date) (retList.get(i))[1]).getTime());
			// logger.debug("Shop visit date is ()****" + ((Date)
			// (retList.get(i))[1]).getTime());
			System.out.println("HospitalAlarmService.findShopVisitByEsn()"
					+ "Shop visit date is ()****"
					+ ((Date) (retList.get(i))[1]).getTime());
			System.out.println("HospitalAlarmService.findShopVisitByEsn()"
					+ "Inside findShopVisitByEsn()::::::" + objMap.size());
			list.add(objMap);

		}

		return list;
	}

	@RequestMapping("equipmentOEEDetails")
	public @ResponseBody List<OEE_Equipment> getEquipmentOEEDetails() {
		System.out
				.println("SOP Inside ShopVisitServiceImplDebug:::getModelCacheDetails()");
		List<OEE_Equipment> oeeEqupVo = new ArrayList<OEE_Equipment>();
		OEE_Equipment oeeEqupVos = null;
		// List<EngineVO> engineVOs = new ArrayList<EngineVO>();
		/*
		 * EngineVO engineVO = new EngineVO();
		 * 
		 * engineVOs.add(engineVO);
		 */
		BigDecimal planProductionTime = null;
		BigDecimal operatingTime = null;
		Double goodUnitProduced = null;
		BigDecimal availability = null;
		BigDecimal performanceSpeedLoss = null;
		Double quality = null;
		BigDecimal oeeCalc = null;
		BigDecimal qualityCalc = null;
		Double qualityDb = null;

		try {

			List<OEE_Equipment_Entity_Dtl> oeeList = oeeRepository.findAll();

			for (OEE_Equipment_Entity_Dtl oee : oeeList) {
				
				oeeEqupVos = new OEE_Equipment();
				System.out
						.println("ShopVisitServiceImpl.getEquipmentOEEDetails()"
								+ oee.getBlockedTime());
				oeeEqupVos.setBlockedTime(oee.getBlockedTime());
				oeeEqupVos.setBreakEqup(oee.getEquipBreak());
				oeeEqupVos.setEquipId(oee.getId());
				oeeEqupVos.setEqupName(oee.getEquipName());
				oeeEqupVos.setFaultTime(oee.getFaultTime());
				oeeEqupVos.setIdealCycleTime(oee.getIdealCycleTime());
				oeeEqupVos.setRejectedUnit(oee.getRejectedUnt());
				oeeEqupVos.setShiftLength(oee.getShiftLength());
				oeeEqupVos.setShiftNum(oee.getShiftNum());
				oeeEqupVos.setStarvedTime(oee.getStravedTime());
				oeeEqupVos.setTotalUnitProduced(oee.getTotalUnitProduced());
				oeeEqupVos.setUpdatedTime(oee.getUpdateDate());
				oeeEqupVos.setSiteEqup(oee.getSite());

				planProductionTime = (oee.getShiftLength().subtract(oee
						.getEquipBreak()));
				planProductionTime.setScale(2, BigDecimal.ROUND_HALF_UP);
				System.out
						.println("HospitalAlarmService.getEquipmentOEEDetails() planProductionTime : "
								+ planProductionTime);
				operatingTime = planProductionTime.subtract(
						oee.getBlockedTime()).subtract(oee.getEquipBreak());
				operatingTime.setScale(2, BigDecimal.ROUND_HALF_UP);

				System.out
						.println("HospitalAlarmService.getEquipmentOEEDetails() operatingTime : "
								+ operatingTime);
				goodUnitProduced = oee.getTotalUnitProduced()
						- oee.getRejectedUnt();

				System.out
						.println("HospitalAlarmService.getEquipmentOEEDetails() goodUnitProduced : "
								+ goodUnitProduced);

				availability = operatingTime.divide(planProductionTime, 2,
						RoundingMode.HALF_UP);
				System.out
						.println("HospitalAlarmService.getEquipmentOEEDetails() availability : "
								+ availability);

				System.out
						.println("HospitalAlarmService.getEquipmentOEEDetails() ***********************");

				BigDecimal dividePer = operatingTime.divide(
						new java.math.BigDecimal((oee.getTotalUnitProduced()
								.toString())), 2, RoundingMode.HALF_UP);

				System.out
						.println("HospitalAlarmService.getEquipmentOEEDetails() dividePer"
								+ dividePer);

				performanceSpeedLoss = oee.getIdealCycleTime().divide(
						dividePer, 2, RoundingMode.HALF_UP);

				quality = (goodUnitProduced / oee.getTotalUnitProduced());
				qualityDb = (double) (quality * 100);

				qualityCalc = BigDecimal.valueOf(Double.parseDouble(String
						.format("%.2f", qualityDb)));

				oeeCalc = availability.multiply(performanceSpeedLoss).multiply(
						qualityCalc);
				oeeCalc.setScale(2, BigDecimal.ROUND_HALF_UP);

				oeeEqupVos.setPlannedProdTime(planProductionTime);
				oeeEqupVos.setOperationTime(operatingTime);
				oeeEqupVos.setGoodUnitProduced(goodUnitProduced);
				oeeEqupVos.setAvailability(availability);
				oeeEqupVos.setPerformanceSpeedLoss(performanceSpeedLoss);
				oeeEqupVos.setQuality(qualityCalc);
				oeeEqupVos.setOee(oeeCalc);

				oeeEqupVo.add(oeeEqupVos);

			}
			// modelVO.setEngines(engineVOs);

		} catch (Exception exception) {
			exception.printStackTrace();
		}
		return oeeEqupVo;
	}
	@RequestMapping("getEquipmentOEEDetailsWithParam/{site}/{cell}/{shiftName}")
	List<Map<String,Object>> getEquipmentOEEDetailsWithParam(
			@PathVariable("site") String site, @PathVariable("cell") String cell, @PathVariable("shiftName") String shiftName){
		Map<String,Object> objMap  = null;
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		BigDecimal planProductionTime = null;
		BigDecimal operatingTime = null;
		Double goodUnitProduced = null;
		BigDecimal availability = null;
		BigDecimal performanceSpeedLoss = null;
		Double quality = null;
		BigDecimal oeeCalc = null;
		BigDecimal qualityCalc = null;
		Double qualityDb = null;
	   try
        {
        
        	List<Object []> retList = this.oeeRepository.getEquipmentOEEDetailsWithParam(site, cell,shiftName);
        	// oeeList = oeEntityRepository.getEquipmentOEEDetailsWithParam(site,cell);
        	
       // }
        
      	for(int i = 0; i < retList.size(); i++){
			objMap	= new HashMap<String, Object>();
			 objMap.put("blockedTime", (retList.get(i))[0]);
			 objMap.put("breakEqup", (retList.get(i))[1]);
			 objMap.put("shiftName", (retList.get(i))[2]);
			 objMap.put("equpName", (retList.get(i))[3]);
			 objMap.put("faultTime", (retList.get(i))[4]);
			 objMap.put("id", (retList.get(i))[5]);
			 objMap.put("idealCycleTime", (retList.get(i))[6]);
			 objMap.put("rejectedUnit", (retList.get(i))[7]);
			 objMap.put("shiftLength", (retList.get(i))[8]);
			 objMap.put("shiftNum", (retList.get(i))[9]);
			 objMap.put("site", (retList.get(i))[10]);
			 objMap.put("stravedTime", (retList.get(i))[11]);
			 objMap.put("totalUnitProduced", (retList.get(i))[12]);
			 objMap.put("updatedDate", (retList.get(i))[13]);
			 
			 //calculation
			 
			 BigDecimal shiftLength = (BigDecimal) retList.get(i)[8];
			 BigDecimal equipBreak =(BigDecimal) retList.get(i)[1];
			 BigDecimal blockedTime = (BigDecimal)retList.get(i)[0];
			 
			 Double totalUnitPrdcd = (Double) retList.get(i)[12];
			 Double rjUnit = (Double)retList.get(i)[7];
			 
			 BigDecimal idealCycleTm = (BigDecimal) retList.get(i)[6];
			 
			 planProductionTime = (shiftLength.subtract(equipBreak));
			 planProductionTime.setScale(2, BigDecimal.ROUND_HALF_UP);
			 
			
			 objMap.put("planProductionTime", planProductionTime);
			 
			 
				System.out
				.println("HospitalAlarmService.getEquipmentOEEDetails() planProductionTime : " + planProductionTime);
				operatingTime = planProductionTime.subtract(blockedTime).subtract(equipBreak);
				operatingTime.setScale(2, BigDecimal.ROUND_HALF_UP);
				
				 objMap.put("operatingTime", operatingTime);
				
				System.out
				.println("HospitalAlarmService.getEquipmentOEEDetails() operatingTime : " + operatingTime);
				goodUnitProduced = totalUnitPrdcd -rjUnit;
				
				objMap.put("goodUnitProduced", goodUnitProduced);
				
				
				System.out
						.println("HospitalAlarmService.getEquipmentOEEDetails() goodUnitProduced : " + goodUnitProduced);
				
				availability = operatingTime.divide(planProductionTime,2, RoundingMode.HALF_UP);
				System.out
				.println("HospitalAlarmService.getEquipmentOEEDetails() availability : " + availability);
				 objMap.put("availability", availability);
				
				System.out.println("HospitalAlarmService.getEquipmentOEEDetails() ***********************");
				
				BigDecimal dividePer= operatingTime.divide( new java.math.BigDecimal((totalUnitPrdcd.toString())),2, RoundingMode.HALF_UP);
				
				System.out
				.println("HospitalAlarmService.getEquipmentOEEDetails() dividePer" + dividePer) ;
				
				performanceSpeedLoss = idealCycleTm.divide(dividePer,2, RoundingMode.HALF_UP);
				
				 objMap.put("performanceSpeedLoss", performanceSpeedLoss);
				quality =  (double) Math.round((double) (goodUnitProduced / totalUnitPrdcd));
				System.out
						.println("HospitalAlarmService.getEquipmentOEEDetails()" + quality);
				qualityDb = (double) (quality*100);
				
				System.out
				.println("HospitalAlarmService.getEquipmentOEEDetails()" + qualityDb);
				
				qualityCalc = BigDecimal.valueOf(Double.parseDouble(String.format( "%.2f", qualityDb )));
				objMap.put("qualityCalc", qualityCalc.setScale(2, BigDecimal.ROUND_HALF_UP));
				
				System.out
				.println("HospitalAlarmService.getEquipmentOEEDetails()" + qualityCalc);
				
				oeeCalc = availability.multiply(performanceSpeedLoss).multiply(qualityCalc);
				objMap.put("oeeCalc", oeeCalc.setScale(2, BigDecimal.ROUND_HALF_UP));
				
												
			 list.add(objMap);
      	}
      	
      	
		}
        catch (Exception ex)
        {
            System.out
					.println(ex);
        }
        return list;
	}
	
	@RequestMapping("/scheduleUpdate")
	public String scheduleUpdate(){
		System.out.println("ShopVisitServiceImpl.scheduleUpdate()");
		final String result = "Hello Thread";
		try{
			Timer timer = new Timer();
			timer.schedule( new TimerTask() {
			    public void run() {
			    	/*final SchedulerVO schedulerVO =  new SchedulerVO();
			    	schedulerVO.setStatus("Scheduler Staretd.....");*/
			    	System.out
							.println(result);
			    	Integer i = 2;
			    	Integer j =1;
			    	Integer k =3;
			    	Integer l =4;
			    	Integer m =5;
			    	Integer n =6;
			    	Integer o =7;
			    	Integer p =8;
			    	
			    	//Long l = Long.valueOf(i.longValue());
			    	 List<OEE_Equipment_Entity_Dtl> oeeList = (List<OEE_Equipment_Entity_Dtl>) oeeRepository.findById(i);
			    	 
			    	 List<OEE_Equipment_Entity_Dtl> oeeListOne = (List<OEE_Equipment_Entity_Dtl>) oeeRepository.findById(j);
			    	 
			    	 List<OEE_Equipment_Entity_Dtl> oeeListThree = (List<OEE_Equipment_Entity_Dtl>) oeeRepository.findById(k);
			    	 
			    	 List<OEE_Equipment_Entity_Dtl> oeeListFour = (List<OEE_Equipment_Entity_Dtl>) oeeRepository.findById(l);
			    	 
			    	 
			    	 List<OEE_Equipment_Entity_Dtl> oeeListFive = (List<OEE_Equipment_Entity_Dtl>) oeeRepository.findById(m);
			    	 
			    	 List<OEE_Equipment_Entity_Dtl> oeeListSix = (List<OEE_Equipment_Entity_Dtl>) oeeRepository.findById(n);
			    	 
			    	 List<OEE_Equipment_Entity_Dtl> oeeListSeven = (List<OEE_Equipment_Entity_Dtl>) oeeRepository.findById(o);
			    	 
			    	 List<OEE_Equipment_Entity_Dtl> oeeListEight = (List<OEE_Equipment_Entity_Dtl>) oeeRepository.findById(p);
			    	 
			    	 
			    	 for(OEE_Equipment_Entity_Dtl dtl : oeeList){
			    	System.out
							.println("Size :" + dtl.getShiftName());
			    	
			    	Integer shiftLen = getRandomInteger(510,550);
			    	Integer equPBr = getRandomInteger(30,35);
			    	Integer blockedTime = getRandomInteger(15,20);
			    	Integer totalUnitPrd = getRandomInteger(591,595);
			    	Integer rjctUnitPrd = getRandomInteger(0,3);
			    	
			    			    	
			    	dtl.setShiftLength((new BigDecimal(shiftLen)));
			    	
			    	System.out
							.println("dtl.getShiftLength :: "  + dtl.getShiftLength());
			    	
			    	dtl.setEquipBreak((new BigDecimal(equPBr)));
			    	
			    	System.out
					.println("dtl.getEquipBreak :: "  + dtl.getEquipBreak());
			    	
			    	dtl.setBlockedTime((new BigDecimal(blockedTime)));
			    	
			    	System.out
					.println("dtl.getBlockedTime :: "  + dtl.getBlockedTime());
			    	
			    	dtl.setTotalUnitProduced(new Double(totalUnitPrd));
			    	
			    	System.out
					.println("dtl.getTotalUnitProduced :: "  + dtl.getTotalUnitProduced());
			    	
			    	dtl.setRejectedUnt(new Double(rjctUnitPrd));
			    	
			    	System.out
					.println("dtl.getRejectedUnt :: "  + dtl.getRejectedUnt());
			    	
			    	oeeRepository.save(dtl);
			    	 }
			    	 
			    	 for(OEE_Equipment_Entity_Dtl dtl : oeeListOne){
					    	System.out
									.println("Size :" + dtl.getShiftName());
					    	
					    	Integer shiftLen = getRandomInteger(510,950);
					    	Integer equPBr = getRandomInteger(30,55);
					    	Integer blockedTime = getRandomInteger(15,30);
					    	Integer totalUnitPrd = getRandomInteger(590,695);
					    	Integer rjctUnitPrd = getRandomInteger(0,15);
					    	
					    			    	
					    	dtl.setShiftLength((new BigDecimal(shiftLen)));
					    	
					    	System.out
									.println("dtl.getShiftLength :: "  + dtl.getShiftLength());
					    	
					    	dtl.setEquipBreak((new BigDecimal(equPBr)));
					    	
					    	System.out
							.println("dtl.getEquipBreak :: "  + dtl.getEquipBreak());
					    	
					    	dtl.setBlockedTime((new BigDecimal(blockedTime)));
					    	
					    	System.out
							.println("dtl.getBlockedTime :: "  + dtl.getBlockedTime());
					    	
					    	dtl.setTotalUnitProduced(new Double(totalUnitPrd));
					    	
					    	System.out
							.println("dtl.getTotalUnitProduced :: "  + dtl.getTotalUnitProduced());
					    	
					    	dtl.setRejectedUnt(new Double(rjctUnitPrd));
					    	
					    	System.out
							.println("dtl.getRejectedUnt :: "  + dtl.getRejectedUnt());
					    	
					    	oeeRepository.save(dtl);
					    	 }
			    	 
			    	 for(OEE_Equipment_Entity_Dtl dtl : oeeListThree){
					    	System.out
									.println("Size :" + dtl.getShiftName());
					    	
					    	Integer shiftLen = getRandomInteger(510,950);
					    	Integer equPBr = getRandomInteger(30,55);
					    	Integer blockedTime = getRandomInteger(15,30);
					    	Integer totalUnitPrd = getRandomInteger(590,695);
					    	Integer rjctUnitPrd = getRandomInteger(0,15);
					    	
					    			    	
					    	dtl.setShiftLength((new BigDecimal(shiftLen)));
					    	
					    	System.out
									.println("dtl.getShiftLength :: "  + dtl.getShiftLength());
					    	
					    	dtl.setEquipBreak((new BigDecimal(equPBr)));
					    	
					    	System.out
							.println("dtl.getEquipBreak :: "  + dtl.getEquipBreak());
					    	
					    	dtl.setBlockedTime((new BigDecimal(blockedTime)));
					    	
					    	System.out
							.println("dtl.getBlockedTime :: "  + dtl.getBlockedTime());
					    	
					    	dtl.setTotalUnitProduced(new Double(totalUnitPrd));
					    	
					    	System.out
							.println("dtl.getTotalUnitProduced :: "  + dtl.getTotalUnitProduced());
					    	
					    	dtl.setRejectedUnt(new Double(rjctUnitPrd));
					    	
					    	System.out
							.println("dtl.getRejectedUnt :: "  + dtl.getRejectedUnt());
					    	
					    	oeeRepository.save(dtl);
					    	 }
			    	 
			    	 
			    	 for(OEE_Equipment_Entity_Dtl dtl : oeeListFour){
					    	System.out
									.println("Size :" + dtl.getShiftName());
					    	
					    	Integer shiftLen = getRandomInteger(410,450);
					    	Integer equPBr = getRandomInteger(10,35);
					    	Integer blockedTime = getRandomInteger(15,20);
					    	Integer totalUnitPrd = getRandomInteger(191,595);
					    	Integer rjctUnitPrd = getRandomInteger(0,10);
					    	
					    			    	
					    	dtl.setShiftLength((new BigDecimal(shiftLen)));
					    	
					    	System.out
									.println("dtl.getShiftLength :: "  + dtl.getShiftLength());
					    	
					    	dtl.setEquipBreak((new BigDecimal(equPBr)));
					    	
					    	System.out
							.println("dtl.getEquipBreak :: "  + dtl.getEquipBreak());
					    	
					    	dtl.setBlockedTime((new BigDecimal(blockedTime)));
					    	
					    	System.out
							.println("dtl.getBlockedTime :: "  + dtl.getBlockedTime());
					    	
					    	dtl.setTotalUnitProduced(new Double(totalUnitPrd));
					    	
					    	System.out
							.println("dtl.getTotalUnitProduced :: "  + dtl.getTotalUnitProduced());
					    	
					    	dtl.setRejectedUnt(new Double(rjctUnitPrd));
					    	
					    	System.out
							.println("dtl.getRejectedUnt :: "  + dtl.getRejectedUnt());
					    	
					    	oeeRepository.save(dtl);
					    	 }
			    	
			    	 for(OEE_Equipment_Entity_Dtl dtl : oeeListFive){
					    	System.out
									.println("Size :" + dtl.getShiftName());
					    	
					    	Integer shiftLen = getRandomInteger(410,490);
					    	Integer equPBr = getRandomInteger(10,35);
					    	Integer blockedTime = getRandomInteger(15,20);
					    	Integer totalUnitPrd = getRandomInteger(321,595);
					    	Integer rjctUnitPrd = getRandomInteger(0,10);
					    	
					    			    	
					    	dtl.setShiftLength((new BigDecimal(shiftLen)));
					    	
					    	System.out
									.println("dtl.getShiftLength :: "  + dtl.getShiftLength());
					    	
					    	dtl.setEquipBreak((new BigDecimal(equPBr)));
					    	
					    	System.out
							.println("dtl.getEquipBreak :: "  + dtl.getEquipBreak());
					    	
					    	dtl.setBlockedTime((new BigDecimal(blockedTime)));
					    	
					    	System.out
							.println("dtl.getBlockedTime :: "  + dtl.getBlockedTime());
					    	
					    	dtl.setTotalUnitProduced(new Double(totalUnitPrd));
					    	
					    	System.out
							.println("dtl.getTotalUnitProduced :: "  + dtl.getTotalUnitProduced());
					    	
					    	dtl.setRejectedUnt(new Double(rjctUnitPrd));
					    	
					    	System.out
							.println("dtl.getRejectedUnt :: "  + dtl.getRejectedUnt());
					    	
					    	oeeRepository.save(dtl);
					    	 }
			    	 for(OEE_Equipment_Entity_Dtl dtl : oeeListSix){
					    	System.out
									.println("Size :" + dtl.getShiftName());
					    	
					    	Integer shiftLen = getRandomInteger(610,950);
					    	Integer equPBr = getRandomInteger(40,55);
					    	Integer blockedTime = getRandomInteger(25,30);
					    	Integer totalUnitPrd = getRandomInteger(490,695);
					    	Integer rjctUnitPrd = getRandomInteger(5,15);
					    	
					    			    	
					    	dtl.setShiftLength((new BigDecimal(shiftLen)));
					    	
					    	System.out
									.println("dtl.getShiftLength :: "  + dtl.getShiftLength());
					    	
					    	dtl.setEquipBreak((new BigDecimal(equPBr)));
					    	
					    	System.out
							.println("dtl.getEquipBreak :: "  + dtl.getEquipBreak());
					    	
					    	dtl.setBlockedTime((new BigDecimal(blockedTime)));
					    	
					    	System.out
							.println("dtl.getBlockedTime :: "  + dtl.getBlockedTime());
					    	
					    	dtl.setTotalUnitProduced(new Double(totalUnitPrd));
					    	
					    	System.out
							.println("dtl.getTotalUnitProduced :: "  + dtl.getTotalUnitProduced());
					    	
					    	dtl.setRejectedUnt(new Double(rjctUnitPrd));
					    	
					    	System.out
							.println("dtl.getRejectedUnt :: "  + dtl.getRejectedUnt());
					    	
					    	oeeRepository.save(dtl);
					    	 }
			    	 
			    	 
			    	 
			    	 for(OEE_Equipment_Entity_Dtl dtl : oeeListEight){
					    	System.out
									.println("Size :" + dtl.getShiftName());
					    	
					    	Integer shiftLen = getRandomInteger(610,750);
					    	Integer equPBr = getRandomInteger(35,75);
					    	Integer blockedTime = getRandomInteger(25,50);
					    	Integer totalUnitPrd = getRandomInteger(675,995);
					    	Integer rjctUnitPrd = getRandomInteger(5,20);
					    	
					    			    	
					    	dtl.setShiftLength((new BigDecimal(shiftLen)));
					    	
					    	System.out
									.println("dtl.getShiftLength :: "  + dtl.getShiftLength());
					    	
					    	dtl.setEquipBreak((new BigDecimal(equPBr)));
					    	
					    	System.out
							.println("dtl.getEquipBreak :: "  + dtl.getEquipBreak());
					    	
					    	dtl.setBlockedTime((new BigDecimal(blockedTime)));
					    	
					    	System.out
							.println("dtl.getBlockedTime :: "  + dtl.getBlockedTime());
					    	
					    	dtl.setTotalUnitProduced(new Double(totalUnitPrd));
					    	
					    	System.out
							.println("dtl.getTotalUnitProduced :: "  + dtl.getTotalUnitProduced());
					    	
					    	dtl.setRejectedUnt(new Double(rjctUnitPrd));
					    	
					    	System.out
							.println("dtl.getRejectedUnt :: "  + dtl.getRejectedUnt());
					    	
					    	oeeRepository.save(dtl);
					    	 }
			    	 for(OEE_Equipment_Entity_Dtl dtl : oeeListSeven){
					    	System.out
									.println("Size :" + dtl.getShiftName());
					    	
					    	Integer shiftLen = getRandomInteger(610,950);
					    	Integer equPBr = getRandomInteger(40,55);
					    	Integer blockedTime = getRandomInteger(25,30);
					    	Integer totalUnitPrd = getRandomInteger(490,695);
					    	Integer rjctUnitPrd = getRandomInteger(5,15);
					    	
					    			    	
					    	dtl.setShiftLength((new BigDecimal(shiftLen)));
					    	
					    	System.out
									.println("dtl.getShiftLength :: "  + dtl.getShiftLength());
					    	
					    	dtl.setEquipBreak((new BigDecimal(equPBr)));
					    	
					    	System.out
							.println("dtl.getEquipBreak :: "  + dtl.getEquipBreak());
					    	
					    	dtl.setBlockedTime((new BigDecimal(blockedTime)));
					    	
					    	System.out
							.println("dtl.getBlockedTime :: "  + dtl.getBlockedTime());
					    	
					    	dtl.setTotalUnitProduced(new Double(totalUnitPrd));
					    	
					    	System.out
							.println("dtl.getTotalUnitProduced :: "  + dtl.getTotalUnitProduced());
					    	
					    	dtl.setRejectedUnt(new Double(rjctUnitPrd));
					    	
					    	System.out
							.println("dtl.getRejectedUnt :: "  + dtl.getRejectedUnt());
					    	
					    	oeeRepository.save(dtl);
					    	 }
			    	 
			    	//schedulerVOs.add(schedulerVO);
			 
			    }
			 }, 0, 30*100);
			 //timer.cancel();
		}
			catch(Exception e){
				System.out.println(e);
			}
			return result;
	}
	
	
	public int getRandomInteger(int maximum, int minimum) {
		return ((int) (Math.random() * (maximum - minimum))) + minimum;
	}
	
	@RequestMapping("/readJSON")
	public String readJSON(){
		
		String status = "Success";
		
		JSONObject jsonObject = null;
	    JSONParser parser = new JSONParser();
	    
	    Properties prop = new Properties();
		String filePath = "";
		
		
	    try {
	    	System.out.println("HospitalAlarmService.readJSON()");
	    	
	    	InputStream inputStream = 
	    		    getClass().getClassLoader().getResourceAsStream("oee.json");
	    	System.out.println("HospitalAlarmService.readJSON() inputStream " + inputStream);
	    					
	    		
	    	JSONObject a = (JSONObject) parser.parse( new InputStreamReader(inputStream, "UTF-8"));
	       	
	       	System.out.println("HospitalAlarmService.readJSON() reading sucess" + a);
	    	
	    	Set<String> keys = a.keySet();
	    	String[] tableName = null;
	    	
	    	Map<String,String> keyValue = new HashMap<String,String>();
	    	
	    	for(String key : keys){
	    		
	    		System.out.println("PureJavaClient.readJson()" + key);
	    		
	    		JSONArray name = (JSONArray) a.get(key);
	    				
	    		for (int i = 0; i < name.size(); i++) {
	    			JSONObject eachRow = (JSONObject) name.get(i);
					
					Set<String> columnsKey = eachRow.keySet();
					for(String columnEachKey : columnsKey){
						
						System.out.println("PureJavaClient.readJson() columnEachKey " + columnEachKey);
						
						eachRow.get(columnEachKey);
						
						if(null!= eachRow.get(columnEachKey)){
							
							/*if(eachRow.get(columnEachKey) instanceof Double){
								
								Double value = (Double) eachRow.get(columnEachKey);
								keyValue.put(columnEachKey, value);
							}else if (eachRow.get(columnEachKey) instanceof Integer){
								Integer value = (Integer) eachRow.get(columnEachKey);
							}
							else if (eachRow.get(columnEachKey) instanceof String){
								
								String value = (String) eachRow.get(columnEachKey);
							}*/
							String value = (String) eachRow.get(columnEachKey).toString();
							System.out.println("PureJavaClient.readJson() value :" + value);
							
							keyValue.put(columnEachKey, value);
							
							
						}
				
					}
					
	    				    		 
	    		}
	    		
	    		
	    	}
	    	
	    	
	    	
	  // }
	    }catch(Exception e){
	    	System.out.println("PureJavaClient.readJson()" + e);
	    	
	    }
		return status;
	}
	
	@RequestMapping("/insertModelRecords/{modelNumber}")
	public String insertModelRecords(@PathVariable("modelNumber") String modelNumber){
		
		String status = "Record inserted success";
		try{
		
		List<Models> engineModels = modelService.findAll();
		
		for (Models engineModel : engineModels) {
			//for (int j = 0; j < 4; j++) {{
			if(engineModel.getModelNumber().equalsIgnoreCase(modelNumber)){
				Engines engine = new Engines();
				engine.setEsn(RandomStringUtils.randomNumeric(6));
				engine.setModels(engineModel);
				engineService.save(engine);
			//}
			}
		}
		

		List<String> partNames=new ArrayList<String>();
		partNames.add("ASSY - COMBUSTION CHAMBER");
		partNames.add("FUEL SYSTEM COMPONENTS");
		partNames.add("ASSY - FAN ROTOR");
		partNames.add("ASSY - HPC ROTOR");
		partNames.add("SUPPORT - BEARING");
		partNames.add("BLADE - FAN");
		partNames.add("LINK - THRUST ENGINE MOUNT");
		partNames.add("SEAL - CDP");
		partNames.add("HOUSING - BEARING NO 1");
		partNames.add("ELECTRICAL - TRANSMITTER");
		partNames.add("PLATE - HPT COOLING");
		partNames.add("SPOOL");
		partNames.add("CASE - LPT");
		partNames.add("ALTERNATOR - GENERATOR STATOR/ROTOR");
		partNames.add("FRAME - EXHAUST");
		partNames.add("CASE - FAN BLADE CONTAINMENT");
		partNames.add("MISC - LOW COST PARTS");
		partNames.add("SENSOR - SENSOR N1 & N2 SPEED");
		partNames.add("ASSY - HPC STATOR");
		partNames.add("DISK - FAN STG 1");
		partNames.add("SHAFT - LPT");
		partNames.add("PUMP - LUBE");
		partNames.add("BLADE - HPT STG 1");
		partNames.add("Blisk - HPC");
		partNames.add("ACTUATOR");
		partNames.add("SEAL - HPC");
		partNames.add("SEAL - TURBINE STG 3 & 4");
		partNames.add("ASSY - ACCESSORY GEARBOX");
		partNames.add("CASE - HPC");
		partNames.add("SEAL - TURBINE STG 5 & 6");
		partNames.add("VALVE");
		partNames.add("ASSY - LPT MODULE");
		partNames.add("BEARING - MAIN #1");
		partNames.add("ASSY - PTO DRIVE");
		partNames.add("MOUNT - ENGINE");
		partNames.add("DISK - HPT STG 1");
		partNames.add("LINER - COMBUSTION");
		partNames.add("DISK - LPT STG 3");
		partNames.add("DISK - LPT STG 4");
		partNames.add("PLUG");
		partNames.add("SEAL - ROTATING AIR");
		partNames.add("SEAL - AIR");
		partNames.add("Blisk - HPC");
		partNames.add("SUPPORT - MOUNT BEAM");
		partNames.add("SEAL - AIR BALANCE PISTON ST");
		partNames.add("ASSY - DOME COMBUSTION");
		partNames.add("NOZZLE - HPT STG 1");
		partNames.add("FRAME - FAN HUB");
		partNames.add("DISK - LPT STG 5");
		partNames.add("COUPLING");
		partNames.add("DISK - HPT STG 2");
		
		List<Engines> engines = (List<Engines>) engineService.findAll();
		Parts partDtls =null;
		Set<Parts> partSet = new HashSet<Parts>();
		System.out.println("HospitalAlarmService.insertModelRecords() partName  size ---------> " + partNames.size());
		System.out.println("HospitalAlarmService.insertModelRecords() Engine details size *****  -> " + engines.size());
		for(Engines engine:engines){
			for (int i = 0; i < partNames.size(); i++) {
				partDtls = new Parts();
				partDtls.setPartSerialNumber(RandomStringUtils.randomAlphanumeric(6));
				partDtls.setIin(RandomStringUtils.randomNumeric(3));
				partDtls.setPartCycleSinceNew(null);
				partDtls.setPartNumber(org.apache.commons.lang.math.RandomUtils.nextInt(4)+RandomStringUtils.randomAlphanumeric(3)+""+i);
				partDtls.setPartName(partNames.get(i));
				partDtls.setCatalogPrice(BigDecimal.valueOf(RandomUtils.randomLongBetween(6000l,100000l)));
				partDtls.setEnginepart(engine);
				partSet.add(partDtls);
				engine.setParts(partSet);
				partService.save(partDtls);
			}
			
		}
		
		
		for (Engines engine : engines) {
			int visitCount = RandomUtils.randomIntgerBetween(5, 10);
			String noOfCyclesSinceNew=RandomStringUtils.randomNumeric(5);
			for (int j = 0; j < visitCount; j++) {
				ShopVisit shopvisit = new ShopVisit();
				shopvisit.setEngineShopvisit(engine);
				shopvisit.setNoOfCyclesSinceNew(noOfCyclesSinceNew);
				Long engineCycleSinceNew=Long.parseLong(shopvisit.getNoOfCyclesSinceNew());
				Long engineCycleSinceLastSV=Long.parseLong(RandomStringUtils.randomNumeric(5));
				Long numberOfCyclesSinceLastSV=0l;
				if(engineCycleSinceLastSV>engineCycleSinceNew){
					numberOfCyclesSinceLastSV=engineCycleSinceLastSV-engineCycleSinceNew;
				}
				else{
					numberOfCyclesSinceLastSV=engineCycleSinceNew-engineCycleSinceLastSV;
				}
				shopvisit.setNoOfCyclesSinceLastVisit(numberOfCyclesSinceLastSV.toString());
				shopvisit.setDateOfVisit(RandomUtils.randomDateBetween(2013, 2014));
				shopvisit.setWorkscope(WorkScope.values()[new Random().nextInt(WorkScope.values().length)].toString());
				shopvisit.setAmount(new BigDecimal(RandomStringUtils.randomNumeric(4)));
				shopVisitService.save(shopvisit);
			}
		}
		
		}
		catch(Exception e){
			System.out.println("HospitalAlarmService.insertModelRecords()" + e);
			return status = "Not success";
		}
		
		
		
		return status;
		
		
	}
	
	@RequestMapping(value = "/TestPost",method = RequestMethod.POST, produces="application/xml")
	public @ResponseBody String testPostService() {
		String output = "Tesing M2m service!!!!!!!!!!";
		
		System.out.println("Tesing M2m service!!!!!!!!!");
		return output;
	}
	
	
	
	
}
