package com.ge.predix.solsvc.training.alarmservice.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ge.predix.solsvc.training.alarmservice.entity.OEE_Equipment_Entity_Dtl;

public interface IOEEEntityRepository extends JpaRepository<OEE_Equipment_Entity_Dtl, Long> {

	String GET_EQIUPMENT_DETAILS = "select epd.blockedTime as blockedTime,epd.equipBreak as equpBreak, epd.shiftName as shiftName,"
			+ "epd.equipName as equpName,epd.faultTime as faultTime,epd.id as equpId,epd.idealCycleTime as idealCycleTime,"
			+ "epd.rejectedUnt as rejectedUnit ,epd.shiftLength  as shiftLength,epd.shiftNum as shiftNum,epd.site as site,"
			+ "epd.stravedTime as stravedTime,epd.totalUnitProduced as totalUnitProduced , "
			+ "epd.updateDate as updatedDate  from OEE_Equipment_Entity_Dtl epd "
			+ "where epd.site= ?1 and epd. equipName=?2 and epd.shiftName=?3";
	
	/**
     * Find by id
     *
     * @param id Reference to the hospital’s id
     * @return CsaCaShopVisitBase object
     */
	//CsaCaShopVisitBase findAll(Long id);
	
	@Override
	List<OEE_Equipment_Entity_Dtl> findAll();
	
	/*@Query(GET_EQIUPMENT_DETAILS)
	 List<OEE_Equipment_Entity> getEquipmentOEEDetailsWithParam(String site,
			String cell, Integer shiftNum, Date updateDate);*/

	 @Query(GET_EQIUPMENT_DETAILS)
	 List<Object []> getEquipmentOEEDetailsWithParam(String site,
			String cell,String shiftName);
	 
	  @Override
	  public OEE_Equipment_Entity_Dtl findOne(Long id);
	  

	  List<OEE_Equipment_Entity_Dtl> findById(Integer id);
	  
	  
	
}

