package com.ge.predix.solsvc.training.alarmservice.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class OEE_Equipment implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String equpName;
	private BigDecimal shiftNum;
	private BigDecimal shiftLength;
	private BigDecimal  breakEqup;
	private BigDecimal blockedTime;
	private BigDecimal starvedTime;
	private BigDecimal faultTime;
	private BigDecimal idealCycleTime;
	private Double totalUnitProduced;
	private Double rejectedUnit;
	private Date updatedTime;
	private Integer equipId;
	private String siteEqup;
	
	
	private BigDecimal plannedProdTime;
	private BigDecimal operationTime;
	private Double goodUnitProduced;
	private BigDecimal availability;
	private BigDecimal performanceSpeedLoss;
	private BigDecimal quality;
	private BigDecimal oee;
	private String shitName;
	

	public String getSiteEqup() {
		return siteEqup;
	}
	public void setSiteEqup(String siteEqup) {
		this.siteEqup = siteEqup;
	}
	
	public BigDecimal getQuality() {
		return quality;
	}
	public void setQuality(BigDecimal quality) {
		this.quality = quality;
	}
	public BigDecimal getOee() {
		return oee;
	}
	public void setOee(BigDecimal oee) {
		this.oee = oee;
	}
	public BigDecimal getAvailability() {
		return availability;
	}
	public void setAvailability(BigDecimal availability) {
		this.availability = availability;
	}
	public BigDecimal getPerformanceSpeedLoss() {
		return performanceSpeedLoss;
	}
	public void setPerformanceSpeedLoss(BigDecimal performanceSpeedLoss) {
		this.performanceSpeedLoss = performanceSpeedLoss;
	}
	public BigDecimal getPlannedProdTime() {
		return plannedProdTime;
	}
	public void setPlannedProdTime(BigDecimal plannedProdTime) {
		this.plannedProdTime = plannedProdTime;
	}
	public BigDecimal getOperationTime() {
		return operationTime;
	}
	public void setOperationTime(BigDecimal operationTime) {
		this.operationTime = operationTime;
	}
	
	public Double getGoodUnitProduced() {
		return goodUnitProduced;
	}
	public void setGoodUnitProduced(Double goodUnitProduced) {
		this.goodUnitProduced = goodUnitProduced;
	}
	public String getEqupName() {
		return equpName;
	}
	public void setEqupName(String equpName) {
		this.equpName = equpName;
	}
	
	
	public BigDecimal getShiftNum() {
		return shiftNum;
	}
	public void setShiftNum(BigDecimal shiftNum) {
		this.shiftNum = shiftNum;
	}
	public BigDecimal getShiftLength() {
		return shiftLength;
	}
	public void setShiftLength(BigDecimal shiftLength) {
		this.shiftLength = shiftLength;
	}
	public BigDecimal getBreakEqup() {
		return breakEqup;
	}
	public void setBreakEqup(BigDecimal breakEqup) {
		this.breakEqup = breakEqup;
	}
	public BigDecimal getBlockedTime() {
		return blockedTime;
	}
	public void setBlockedTime(BigDecimal blockedTime) {
		this.blockedTime = blockedTime;
	}
	public void setStarvedTime(BigDecimal starvedTime) {
		this.starvedTime = starvedTime;
	}
	public void setFaultTime(BigDecimal faultTime) {
		this.faultTime = faultTime;
	}
	
	public Date getUpdatedTime() {
		return updatedTime;
	}
	public void setUpdatedTime(Date updatedTime) {
		this.updatedTime = updatedTime;
	}
	public Integer getEquipId() {
		return equipId;
	}
	public void setEquipId(Integer equipId) {
		this.equipId = equipId;
	}


	public Double getTotalUnitProduced() {
		return totalUnitProduced;
	}
	public void setTotalUnitProduced(Double totalUnitProduced) {
		this.totalUnitProduced = totalUnitProduced;
	}
	public Double getRejectedUnit() {
		return rejectedUnit;
	}
	public void setRejectedUnit(Double rejectedUnit) {
		this.rejectedUnit = rejectedUnit;
	}
	public BigDecimal getStarvedTime() {
		return starvedTime;
	}
	public BigDecimal getFaultTime() {
		return faultTime;
	}
	public BigDecimal getIdealCycleTime() {
		return idealCycleTime;
	}
	public void setIdealCycleTime(BigDecimal idealCycleTime) {
		this.idealCycleTime = idealCycleTime;
	}
	public String getShitName() {
		return shitName;
	}
	public void setShitName(String shitName) {
		this.shitName = shitName;
	}
	
	
}
