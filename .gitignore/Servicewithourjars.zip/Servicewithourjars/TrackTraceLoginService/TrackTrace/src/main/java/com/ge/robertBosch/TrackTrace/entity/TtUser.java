package com.ge.robertBosch.TrackTrace.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the TT_USER database table.
 * 
 */
@Entity
@Table(name="TT_USER")
@NamedQuery(name="TtUser.findAll", query="SELECT t FROM TtUser t")
public class TtUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TT_USER_ID_GENERATOR", sequenceName="TT_SEQ_USR")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TT_USER_ID_GENERATOR")
	private long id;

	private String email;

	private String flag;

	@Column(name="FULL_NAME")
	private String fullName;

	private String password;

	@Column(name="USER_NAME")
	private String userName;

	//bi-directional many-to-one association to M2mDevice
	@OneToMany(mappedBy="ttUser")
	private List<M2mDevice> m2mDevices;

	//bi-directional many-to-one association to TtAddress
	@OneToMany(mappedBy="ttUser")
	private List<TtAddress> ttAddresses;

	public TtUser() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFlag() {
		return this.flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getFullName() {
		return this.fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public List<M2mDevice> getM2mDevices() {
		return this.m2mDevices;
	}

	public void setM2mDevices(List<M2mDevice> m2mDevices) {
		this.m2mDevices = m2mDevices;
	}

	public M2mDevice addM2mDevice(M2mDevice m2mDevice) {
		getM2mDevices().add(m2mDevice);
		m2mDevice.setTtUser(this);

		return m2mDevice;
	}

	public M2mDevice removeM2mDevice(M2mDevice m2mDevice) {
		getM2mDevices().remove(m2mDevice);
		m2mDevice.setTtUser(null);

		return m2mDevice;
	}

	public List<TtAddress> getTtAddresses() {
		return this.ttAddresses;
	}

	public void setTtAddresses(List<TtAddress> ttAddresses) {
		this.ttAddresses = ttAddresses;
	}

	public TtAddress addTtAddress(TtAddress ttAddress) {
		getTtAddresses().add(ttAddress);
		ttAddress.setTtUser(this);

		return ttAddress;
	}

	public TtAddress removeTtAddress(TtAddress ttAddress) {
		getTtAddresses().remove(ttAddress);
		ttAddress.setTtUser(null);

		return ttAddress;
	}

}
